//MuSeqBox.C------------------------------------------------------------------//
//                                                                            //
//Authors: Liqun Xing, Volker Brendel                                         //
//                                                                            //
//Correspondence:                                                             //
//   Volker Brendel, Department of Biology                                    //
//   Indiana University, Bloomington, IN 47405                                //
//   212 South Hawthorne Drive                                                //
//   Tel.: (812) 855-7074; Email: vbrendel@indiana.edu                        //
//                                                                            //
//                               Version 5.5  Last modified: October 13, 2016 //
//                                                                            //
//                                                                            //
//      This program is free software; you can redistribute it and/or         //
//      modify it under the terms of the GNU General Public License           //
//      as published by the Free Software Foundation; either version 3        //
//      of the License, or (at your option) any later version.                //
//                                                                            //
//      This program is distributed in the hope that it will be useful,       //
//      but WITHOUT ANY WARRANTY; without even the implied warranty of        //
//      MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         //
//      GNU General Public License for more details (in the distribution      //
//      of this software or http://www.gnu.org/licenses/gpl.txt).             //
//                                                                            //
//----------------------------------------------------------------------------//

#include "msbFunctions.h"

int main(int argc, char *argv[])
{
 char  *Fname, wFile[256];                        //rFile: readFile; wFile: writeFile
 char  wSelect[256];
 char  wIntron[256], wFlgthRecord[256], wHomolog[256], wRepeat[256];
 int   i, j, k;
 int   Pstyle=4;                                  //default print style is 4
 int   cc=0;
 int   bgc=5;
 int   bgci=5;
 int   bgcg=5;
 int   bgcr=5;
 int   bgch=5;

 char SQf[IDLen], Hit1[AnnColWidthMax+1], Hit2[AnnColWidthMax+1], chimeratype[3];
 long XYfh[2], XYsh[2];
 int MaxOverlap = 0, MinExtension = 0;
 int chimera;

 Boolean  Finput;
 Boolean  Foutput = no;
 Boolean  Rdatafile = no;
 Boolean  OutputFlgthRecord = no;
 Boolean  OutputIntron = no;
 Boolean  OutputHomolog = no;
 Boolean  OutputChimeras = no;
 Boolean  OutputRepeat = no;
 Boolean  Verbose = no;
 Boolean  CheckFormat = yes;
 Boolean  Web = no;
 OutFmt   Fmt = text;

 if (argc < 2) {
  Syntax();
  exit(0);
 }
 else {
  int Params;
  Params = argc - 1;                              //count the online parameters

  i = 1;
  while (i < argc) {
   if (argv[i][0] == '-') {
    switch (argv[i][1]) {
     case '\0':
      i++;
      Finput = no;
      Params = Params - 1;
      break;
     case 'i':
      i++;
      Finput = yes;
      Fname = argv[i];
      i++;
      Params = Params - 2;
      break;
     case 'g':
     case 'G':
      i++;
      GetSPn = yes;
      break;
     case 'n':
      if (Params - 2 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        Nhits = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 2;
      break;
     case 's':
      if (Params - 2 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        Nhsps = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 2;
      break;
     case 'p':
     case 'P':
      if (Params - 2 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        Pstyle = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 2;
      break;
     case 'l':
      if (Params - 2 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        QidSize = atoi(argv[i]);
        if (QidSize > IDLen) QidSize = IDLen;
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 2;
      break;
     case 'd':
      if (Params - 2 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        DbColWidthPrt = atoi(argv[i]);
        if (DbColWidthPrt > DbColWidthMax) DbColWidthPrt = DbColWidthMax;
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 2;
      break;
     case 'L':
      if (Params - 2 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        AnnColWidthPrt = atoi(argv[i]);
        if (AnnColWidthPrt > AnnColWidthMax) AnnColWidthPrt = AnnColWidthMax;
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 2;
      break;
     case 'k':
      if (Params - 2 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        SrcSize = atoi(argv[i]);
        if (SrcSize > IDLen) SrcSize = IDLen;
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 2;
      break;
     case 'o':
     case 'O':
      i++;
      Foutput = yes;
      strcpy(wFile, argv[i]);
      i++;
      Params = Params - 2;
      break;
     case 'f':
     case 'F':
      if (Params - 8 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        StartPosi = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        EndPosi = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        Startq = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        Endq = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        SCpct = atof(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        QCpct = atof(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if ( argv[i][0] == 47  || (argv[i][0] == 46) ||
        (argv[i][0] >= 65 && argv[i][0] <= 93) ||
       (argv[i][0] >= 97 && argv[i][0] <= 122)) {
        strcpy(wFlgthRecord, argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 6;
      OutputFlgthRecord = yes;
      break;
     case 'a':
     case 'A':
      if (Params - 5 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        Hpct = atof(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        MAO = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        HCpct = atof(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if ((argv[i][0] == 47) || (argv[i][0] == 46) ||
        (argv[i][0] >= 65 && argv[i][0] <= 93) ||
       (argv[i][0] >= 97 && argv[i][0] <= 122)) {
        strcpy(wHomolog, argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 5;
      OutputHomolog = yes;
      break;
     case 'I':
      if (Params - 4 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        MinGaps = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if(argv[i][0] <= 57 && argv[i][0] >=48 ) {
        if(strcmp(argv[i],"1")==0) { IndelType=1; }
        else {
         if(strcmp(argv[i],"2")==0) { IndelType=2; }
         else { Warning(); exit(0); }
        }
       }
       else {
        Warning(); exit(0);
       }
       i++;
       if ((argv[i][0] == 47) || (argv[i][0] == 46) ||
        (argv[i][0] >= 65 && argv[i][0] <= 93) ||
       (argv[i][0] >= 97 && argv[i][0] <= 122)) {
        strcpy(wIntron, argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 4;
      OutputIntron = yes;
      break;
     case 'm':
     case 'M':
      if (Params - 3 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        MaxOverlap = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        MinExtension = atoi(argv[i]);
       }
       else {
        Warning(); exit(0);
       }
      }
      i++;
      Params = Params - 3;
      OutputChimeras = yes;
      break;
     case 'r':
     case 'R':
      if (Params - 4 < 0) {
       Warning();
       exit(0);
      }
      else {
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        MinReps = atoi(argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
       i++;
       if (argv[i][0] <= 57 && argv[i][0] >= 48) {
        if (strcmp(argv[i], "1") == 0) { RepsSrc = 1; }
        else {
         if(strcmp(argv[i],"2")==0) { RepsSrc= 2; }
         else { Warning(); exit(0); }
        }
       }
       else {
        Warning(); exit(0);
       }
       i++;
       if ((argv[i][0] == 47)  || (argv[i][0] == 46) ||
        (argv[i][0] >= 65 && argv[i][0] <= 93) ||
       (argv[i][0] >= 97 && argv[i][0] <= 122)) {
        strcpy(wRepeat, argv[i]);
       }
       else {
        Warning();
        exit(0);
       }
      }
      i++;
      Params = Params - 4;
      OutputRepeat = yes;
      break;
     case 't':
     case 'T':
      i++;
      Fmt = text;
      break;
     case 'h':
      i++;
      Fmt = html;
      break;
     case 'q':
     case 'Q':
      i++;
      Verbose = yes;
      break;
     case 'H':
      Syntax();
      exit(0);
      break;
     case 'c':
     case 'C':
      i++;
      Rdatafile = yes;
      strcpy(wSelect, argv[i]);
      i++;
      Params = Params - 2;
      break;
     case 'z':
     case 'Z':
      i++;
      CheckFormat=no;
      break;
     case 'w':                                    //undocumented flag used to change error message
     case 'W':                                    //when running web interface
      i++;
      Web = yes;
      break;
     default:
      Warning();
      exit(0);
      break;

    }                                             //end of switch(argv[i][1]) {

   }
   else {
    Warning();
    exit(0);
   }
  }
 }                                                // end of if(argc<2) {

 istream *rF;
 ifstream Fin;
 if (Finput == yes) {
  Fin.open(Fname);
  if (!Fin) {
   cout << "\nError: file '" << Fname << "' not found !!!\n\n";
   exit(1);
  }
  else {
   rF = &Fin;
  }
 }
 else {
  rF = &cin;
 }

 ostream *W;
 ofstream wF;
 if (Foutput == yes) {
  if (Fmt == html) {
   strcat(wFile, ".html");
  }
  wF.open(wFile);
  if (Fmt == html) {
   wF << "<HTML>\n" << "<HEAD>\n" << "<TITLE>Tabulated BLAST Output</TITLE>\n"
    << "</HEAD>\n" << "<BODY>\n" << "\n<PRE>\n";
  }
  W = &wF;
 }
 else {
  wF.close();
  W = &cout;
  if (Fmt == html) {
   *W << "<HTML>\n" << "<HEAD>\n" << "<TITLE>Tabulated BLAST Output</TITLE>\n"
    << "</HEAD>\n" << "<BODY>\n" << "\n<PRE>\n";
  }
 }

 int OP[9];                                       //operator for 0:<>, 1:>, 2:>=, 3:<, 4:<=

 int QLEN, HLEN, SLEN, GAPS;
 float QCOV, SCOV, IDEN, SCOR;
 double EVAL;
 char Key[200], QKey[200], Line[200];
 char ch, SQn[IDLen], DB[DbColWidthMax], DBn[DbColWidthMax], PGM[20];
 char ID[IDLen], SPn[IDLen], Annotation[AnnColWidthMax+1]= "\0";
 BLAST BST;
 Tdbase Dbase;
 Boolean lst, Exit, id, GetDBn;
 Boolean retrieve_dbinfo;                         //BLAST database and parameter info
 int HSP = 0, C;
 long Nbp, FLen, Len;
 int NC;                                          //cout space

 DTtype SD;                                       //Sequence Data, SD
 FileType Ftype;                                  //BLAST or parsed output
 //long      Tm;

 string querystring = "", keystring = "", description = "";
 size_t foundyou;
 int gifound, foundfirst;
 char queryarray[512];
 char  Nlet[25], Nseq[25];
 char  Matrix[50], Penalty[80];
 char  Lambda_1[14], K_val_1[14], H_val_1[14];
 char  Lambda_2[14], K_val_2[14], H_val_2[14];
 strcpy(Lambda_2, "n/a");

 int Rc = 0, Ic = 0, Gc = 0, Hc = 0;

 do {
  (*rF) >> Key;
 } while (strcmp(Key, "BLASTX") != 0 && strcmp(Key, "BLASTN") != 0 &&
  strcmp(Key, "BLASTP") != 0 && strcmp(Key, "TBLASTN") != 0 &&
                                                  //blast output
  strcmp(Key, "TBLASTX") != 0 && strcmp(Key, "RPSBLAST") != 0 && strcmp(Key, "RPSTBLASTN") != 0 &&
  strcmp(Key, "BLASTx:") != 0 && strcmp(Key, "BLASTp:") != 0 &&
  strcmp(Key, "BLASTn:") != 0 && strcmp(Key, "TBLASTn:") != 0 &&
                                                  //MuSeqBox output
  strcmp(Key, "TBLASTx:") && strcmp(Key, "rpsBLAST:") && strcmp(Key, "rpsTBLASTn:") && (*rF).peek() != EOF);

 if (Key[0] == 'T') {
  switch (Key[6]) {
   case 'X':
    strcpy(PGM, "TBLASTx");
    BST = tblastx;
    Ftype = blast;
    break;
   case 'N':
    strcpy(PGM, "TBLASTn");
    BST = tblastn;
    Ftype = blast;
    break;
   case 'x':
    strcpy(PGM, "TBLASTx");
    BST = tblastx;
    Ftype = parsed;
    (*rF).ignore(100,':');
    (*rF) >>i;
    if(i!=4) {
     cout << "\n\nInvalid file input format. The MuSeqBox file must be in";
     cout << "\ndefault print format (pstyle=4) if used as input file.\n\n";
     exit(0);
    }
    break;
   case 'n':
    strcpy(PGM, "TBLASTn");
    BST = tblastn;
    Ftype = parsed;
    (*rF).ignore(100,':');
    (*rF) >>i;
    if(i!=4) {
     cout << "\n\nInvalid file input format. The MuSeqBox file must be in";
     cout << "\ndefault print format (pstyle=4) if used as input file.\n\n";
     exit(0);
    }
    break;
  }
 }
 else if (Key[0] == 'B') {
  switch (Key[5]) {
   case 'X':
    strcpy(PGM, "BLASTx");
    BST = blastx;
    Ftype = blast;
    break;
   case 'P':
    strcpy(PGM, "BLASTp");
    BST = blastp;
    Ftype = blast;
    break;
   case 'N':
    strcpy(PGM, "BLASTn");
    BST = blastn;
    Ftype = blast;
    break;
   case 'x':
    strcpy(PGM, "BLASTx");
    BST = blastx;
    Ftype = parsed;
    (*rF).ignore(100,':');
    (*rF) >>i;
    if(i!=4) {
     cout << "\n\nInvalid file input format. The MuSeqBox file must be in";
     cout << "\ndefault print format (pstyle=4) if used as input file.\n\n";
     exit(0);
    }
    break;
   case 'p':
    strcpy(PGM, "BLASTp");
    BST = blastp;
    Ftype = parsed;
    (*rF).ignore(100,':');
    (*rF) >>i;
    if(i!=4) {
     cout << "\n\nInvalid file input format. The MuSeqBox file must be in";
     cout << "\ndefault print format (pstyle=4) if used as input file.\n\n";
     exit(0);
    }
    break;
   case 'n':
    strcpy(PGM, "BLASTn");
    BST = blastn;
    Ftype = parsed;
    (*rF).ignore(100,':');
    (*rF) >>i;
    if(i!=4) {
     cout << "\n\nInvalid file input format. The MuSeqBox file must be in";
     cout << "\ndefault print format (pstyle=4) if used as input file.\n\n";
     exit(0);
    }
    break;
  }
 }
 else if (Key[0] == 'R') {
  switch (Key[3]) {
   case 'B':
    strcpy(PGM, "rpsBLAST");
    BST = rpsblast;
    Ftype = blast;
    break;
   case 'T':
    strcpy(PGM, "rpsTBLASTn");
    BST = rpstblastn;
    Ftype = blast;
    break;
  }
  GetSPn = no;
 }
 else if (Key[0] == 'r') {
  switch (Key[3]) {
   case 'B':
    strcpy(PGM, "rpsBLAST");
    BST = rpsblast;
    Ftype = parsed;
    (*rF).ignore(100,':');
    (*rF) >>i;
    if(i!=4) {
     cout << "\n\nInvalid file input format. The MuSeqBox file must be in";
     cout << "\ndefault print format (pstyle=4) if used as input file.\n\n";
     exit(0);
    }
    break;
   case 'T':
    strcpy(PGM, "rpsTBLASTn");
    BST = rpstblastn;
    Ftype = parsed;
    (*rF).ignore(100,':');
    (*rF) >>i;
    if(i!=4) {
     cout << "\n\nInvalid file input format. The MuSeqBox file must be in";
     cout << "\ndefault print format (pstyle=4) if used as input file.\n\n";
     exit(0);
    }
    break;
  }
 }                                                //searching for blast program name

 // NOW NEED TO PARSE THE QueryID line TO FIGURE OUT COLUMN WIDTHS AND GetSPn status!!
 // INPUT has to be pstyle=4
 if (Ftype == parsed) {
  getline(*rF, description);                      // absorb closing ) after "(pstyle=4"
  foundyou=description.find("QueryID");
  while (foundyou==string::npos) {
   getline(*rF, description);
   foundyou=description.find("QueryID");
  };
  foundyou=description.find("SubjectID");
  if (foundyou==string::npos) {
   cout << "\nProblem parsing the MuSeqBox input file.  Are you sure it was generated with pstyle=4 (-p 4 option)?\n";
   exit(0);
  };                                              // incorrect input file
  foundfirst = (int)foundyou;
  QidSize = foundfirst-1;
  foundyou=description.find("Db");
  foundfirst = (int)foundyou;
  foundyou=description.find("Annotation",foundyou+1);
  DbColWidthPrt = (int)foundyou - foundfirst - 1;
  foundfirst = (int)foundyou;
  foundyou=description.find("Source",foundyou+1);
  if (foundyou!=string::npos) {
   AnnColWidthPrt = (int)foundyou - foundfirst - 1;
   GetSPn = yes;
   getline(*rF, description);
   SrcSize = (int)description.length() - (int)foundyou;
  }
  else {
   getline(*rF, description);
   AnnColWidthPrt = (int)description.length() - (int)foundfirst;
  }
 }

 //time(&Tm);
 *W << PGM << ": ";
 if (Nhits == MaxHITs) { *W << "All hits selected; "; }
 else { *W << "First " << Nhits << " hits selected; "; }
 if (Nhsps == MaxHSPs) { *W << "All HSPs selected ("; }
 else { *W << "Best " << Nhsps << " HSPs selected ("; }
 *W << "pstyle: " <<Pstyle << ")\n";
 if (Rdatafile == yes) { *W << "        Selection Criteria: "; }
 else { *W <<endl; Headings(W, BST, Pstyle); };
 //wF <<ctime(&Tm) <<endl;

 ofstream wG;
 if (OutputFlgthRecord == yes) {
  if (Fmt == html) { strcat(wFlgthRecord, ".html"); }
  wG.open(wFlgthRecord);
  if (Fmt == html) {
   wG << "<HTML>\n" << "<HEAD>\n" << "<TITLE>Tabulated BLAST Output</TITLE>\n"
    << "</HEAD>\n" << "<BODY>\n" << "<A NAME=" "top" ">\n" << "<A NAME=" "file1" ">\n"
    << "<H3>Queries containing a potential full-length CDS:</H3>\n"
    << "<HR>\n" << "\n<PRE>\n";
  }
  wG << PGM << ": ";
  if (Nhits == MaxHITs) { wG << "All hits selected. "; }
  else { wG << "Top " << Nhits << " hits selected. "; }
  wG << "Selected queries are likely to contain a full-length CDS (pstyle:"
   <<Pstyle << ")\n";
  wG << "        Selection Criteria: v5s <=" <<StartPosi << ", v3s <=" <<EndPosi<< ", v5q <="<<Startq<< ", v3q <="<<Endq;
  wG << ", scv >=" <<SCpct << "%, qcv >=" <<QCpct << "%\n\n";
  Headings(&wG, BST, Pstyle);
 }

 ofstream wH;
 if (OutputHomolog == yes) {
  if (Fmt == html) { strcat(wHomolog, ".html"); }
  wH.open(wHomolog);
  if (Fmt == html) {
   wH << "<HTML>\n" << "<HEAD>\n" << "<TITLE>Tabulated BLAST Output</TITLE>\n"
    << "</HEAD>\n" << "<BODY>\n" << "<A NAME=" "top" ">\n" << "<A NAME=" "file1" ">\n"
    << "<H3>Queries with strong similarity to subject sequences:</H3>\n"
    << "<HR>\n" << "\n<PRE>\n";
  }
  wH << PGM << ": ";
  if (Nhits == MaxHITs) { wH << "All hits selected. "; }
  else { wH << "Top " << Nhits << " hits selected. "; }
  wH << "Selected queries show strong similarity to subject sequences (pstyle:"
   <<Pstyle << ")\n";
  wH << "        Selection Criteria: pid >=" <<Hpct << "% at each HSP, scv >=" <<HCpct;
  wH << "%; mao <=" <<MAO << "\n\n";
  Headings(&wH, BST, Pstyle);
 }

 ofstream wI;
 if (OutputIntron == yes) {
  if (Fmt == html) { strcat(wIntron, ".html"); }
  wI.open(wIntron);
  if (Fmt == html) {
   wI << "<HTML>\n" << "<HEAD>\n" << "<TITLE>Tabulated BLAST Output</TITLE>\n"
    << "</HEAD>\n" << "<BODY>\n" << "<A NAME=" "top" ">\n" << "<A NAME=" "file1" ">\n"
    << "<H3>Queries representing potential alternatively spliced transcripts:</H3>\n"
    << "<HR>\n" << "\n<PRE>\n";
  }
  wI << PGM << ": ";
  if (Nhits == MaxHITs) { wI << "All hits selected. "; }
  else { wI << "Top " << Nhits << " hits selected. "; }
  wI << "Selected queries may represent alternatively spliced transcripts (pstyle:"
   <<Pstyle << ")\n";
  wI << "        Selection Criteria: at least ";
  switch(IndelType) {
   case 1:
    if(BST==blastx || BST==blastn || BST==tblastx) {
     wI <<MinGaps << " nucleotide ";
    }
    else { wI <<MinGaps << " amino acids "; }
    wI << "segment insertion (i.e., indel >=" <<MinGaps << ")\n\n";
    break;
   case 2:
    switch(BST) {
     case blastx: wI <<MinGaps/3 << " amino acids "; break;
     case blastp: case rpsblast: wI <<MinGaps << " amino acids "; break;
     case tblastn: case rpstblastn: wI <<MinGaps*3 << " nucleotide "; break;
     default: wI <<MinGaps << " nucleotide "; break;
    }
    wI << "segment deletion (i.e., indel >=" <<MinGaps << ")\n\n";
    break;
  }
  Headings(&wI, BST, Pstyle);
 }

 ofstream wR;
 if (OutputRepeat == yes) {
  if (Fmt == html) { strcat(wRepeat, ".html"); }
  wR.open(wRepeat);
  if (Fmt == html) {
   wR << "<HTML>\n" << "<HEAD>\n" << "<TITLE>Tabulated BLAST Output</TITLE>\n"
    << "</HEAD>\n" << "<BODY>\n" << "<A NAME=" "top" ">\n" << "<A NAME=" "file1" ">\n"
    << "<H3>Query/subject pairs with repeat structures:</H3>\n"
    << "<HR>\n" << "\n<PRE>\n";
  }
  wR << PGM << ": ";
  if (Nhits == MaxHITs) { wR << "All hits selected. "; }
  else { wR << "Top " << Nhits << " hits selected. "; }
  wI << "Selected query/subject pairs contain repeat structures (pstyle:"
   <<Pstyle << ")\n";
  wR << "        Selection Criteria: minimal ";
  switch (BST) {
   case blastx:
    if(RepsSrc==1) {
     wR << " nucleotide repeat size (rps) >=" <<MinReps;
    }
    else {
     wR << " peptide repeat size (rps) >=" <<MinReps/3;
    }
    break;
   case blastn:
   case tblastx:
    wR << " nucleotide repeat size (rps) >=" <<MinReps;
    break;
   case blastp: case rpsblast:
    wR << " peptide repeat size (rps) >=" <<MinReps;
    break;
   case tblastn: case rpstblastn:
    if(RepsSrc==1) {
     wR << " peptide repeat size (rps) >=" <<MinReps;
    }
    else {
     wR << " nucleotide repeat size (rps) >=" <<MinReps*3;
    }
    break;
  }

  switch (RepsSrc) {
   case 1: wR << ") within the query\n\n"; break;
   case 2: wR << ") within the subject\n\n"; break;
  }
  Headings(&wR, BST, Pstyle);
 }

 ifstream rP;
 if (Rdatafile == yes) {
  rP.open(wSelect);
  if (!rP) {
   cout << "\nError: file '" << wSelect << "' not found, program stopped.\n\n";
   exit(1);
  }
  else {
   while (rP.peek() != EOF) {
    rP >> Key;
    switch (Key[0]) {
     case '1':
      rP >> Line >> Line >> Line;
      rP >> QLEN;
      i = 0;
      break;
     case '2':
      rP >> Line >> Line >> Line;
      rP >> HLEN;
      i = 1;
      break;
     case '3':
      rP >> Line >> Line >> Line;
      rP >> SLEN;
      i = 2;
      break;
     case '4':
      rP >> Line >> Line >> Line;
      rP >> SCOV;
      i = 3;
      break;
     case '5':
      rP >> Line >> Line >> Line;
      rP >> QCOV;
      i = 4;
      break;
     case '6':
      rP >> Line >> Line >> Line;
      rP >> IDEN;
      i = 5;
      break;
     case '7':
      rP >> Line >> Line >> Line;
      rP >> GAPS;
      i = 6;
      break;
     case '8':
      rP >> Line >> Line >> Line;
      rP >> SCOR;
      i = 7;
      break;
     case '9':
      rP >> Line >> Line >> Line;
      rP >> EVAL;
      i = 8;
      break;
     default:
      rP.ignore(500,'\n');
      continue;
      break;
    }

    switch (Line[0]) {
     case '>':
      if (Line[1] == '\0') {
       OP[i] = 1;
      }
      else {
       if (Line[1] == '=') {
        OP[i] = 2;
       }
      }
      break;
     case '<':
      if (Line[1] == '\0') {
       OP[i] = 3;
      }
      else {
       if (Line[1] == '=') {
        OP[i] = 4;
       }
       else {
        if (Line[1] == '>') {
         OP[i] = 0;
        }
       }
      }
      break;
    }

    switch (i) {
     case 0:
      if (OP[0] > 0) {
       if (OP[0] == 1) {
        *W << "QLen > " << QLEN << "; ";
       }
       if (OP[0] == 2) {
        *W << "QLen >= " << QLEN << "; ";
       }
       if (OP[0] == 3) {
        *W << "QLen < " << QLEN << "; ";
       }
       if (OP[0] == 4) {
        *W << "QLen <=" << QLEN << "; ";
       }
      }
      break;
     case 1:
      if (OP[1] > 0) {
       if (OP[1] == 1) {
        *W << "HLen > " << HLEN << "; ";
       }
       if (OP[1] == 2) {
        *W << "HLen >= " << HLEN << "; ";
       }
       if (OP[1] == 3) {
        *W << "HLen < " << HLEN << "; ";
       }
       if (OP[1] == 4) {
        *W << "HLen <=" << HLEN << "; ";
       }
      }
      break;
     case 2:
      if (OP[2] > 0) {
       if (OP[2] == 1) {
        *W << "SLen > " << SLEN << "; ";
       }
       if (OP[2] == 2) {
        *W << "SLen >= " << SLEN << "; ";
       }
       if (OP[2] == 3) {
        *W << "SLen < " << SLEN << "; ";
       }
       if (OP[2] == 4) {
        *W << "SLen <=" << SLEN << "; ";
       }
      }
      break;
     case 3:
      if (OP[3] > 0) {
       if (OP[3] == 1) {
        *W << "CovS > " << SCOV << "; ";
       }
       if (OP[3] == 2) {
        *W << "CovS >= " << SCOV << "; ";
       }
       if (OP[3] == 3) {
        *W << "CovS < " << SCOV << "; ";
       }
       if (OP[3] == 4) {
        *W << "CovS <=" << SCOV << "; ";
       }
      }
      break;
     case 4:
      if (OP[4] > 0) {
       if (OP[4] == 1) {
        *W << "CovQ > " << QCOV << "; ";
       }
       if (OP[4] == 2) {
        *W << "CovQ >= " << QCOV << "; ";
       }
       if (OP[4] == 3) {
        *W << "CovQ < " << QCOV << "; ";
       }
       if (OP[4] == 4) {
        *W << "CovQ <=" << QCOV << "; ";
       }
      }
      break;
     case 5:
      if (OP[5] > 0) {
       if (OP[5] == 1) {
        *W << "Pid > " << IDEN << "; ";
       }
       if (OP[5] == 2) {
        *W << "Pid >= " << IDEN << "; ";
       }
       if (OP[5] == 3) {
        *W << "Pid < " << IDEN << "; ";
       }
       if (OP[5] == 4) {
        *W << "Pid <=" << IDEN << "; ";
       }
      }
      break;
     case 6:
      if (OP[6] > 0) {
       if (OP[6] == 1) {
        *W << "Gaps > " << GAPS << "; ";
       }
       if (OP[6] ==2) {
        *W << "Gaps >= " <<GAPS << "; ";
       }
       if (OP[6] ==3) {
        *W << "Gaps < " <<GAPS << "; ";
       }
       if (OP[6] ==4) {
        *W << "Gaps <= " <<GAPS << "; ";
       }
      }
      break;
     case 7:
      if (OP[7] > 0) {
       if (OP[7] == 1) {
        *W << "Score > " << SCOR << "; ";
       }
       if (OP[7] == 2) {
        *W << "Score >= " << SCOR << "; ";
       }
       if (OP[7] == 3) {
        *W << "Score < " << SCOR << "; ";
       }
       if (OP[7] == 4) {
        *W << "Score <=" << SCOR << "; ";
       }
      }
      break;
     case 8:
      if (OP[8] > 0) {
       if (OP[8] == 1) {
        *W << "Eval > " << EVAL << "; ";
       }
       if (OP[8] == 2) {
        *W << "Eval >= " << EVAL << "; ";
       }
       if (OP[8] == 3) {
        *W << "Eval < " << EVAL << "; ";
       }
       if (OP[8] == 4) {
        *W << "Eval <=" << EVAL << "; ";
       }
      }
      break;
    }
    rP.ignore(500, '\n');
   }                                              //end of while(rP.peek()!=EOF) {
   rP.close();
   *W << "\n\n";
   Headings(W, BST, Pstyle);
  }
 }
 else {
  rP.close();
 }
 if (Fmt == html) {
  *W<< "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"22\">";
  if(wI) {
   wI << "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"22\">";
  }
  if(wG) {
   wG<< "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"22\">";
  }
  if(wR) {
   wR<< "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"22\">";
  }
  if(wH) {
   wH<< "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"22\">";
  }
 }

 if (Ftype == blast) {

  retrieve_dbinfo = yes;                          //check whether database info has been read
  while ((*rF).peek() != EOF) {                   //start searching output file
   do {
    (*rF) >> Key;
    NewQuery:
    if (strcmp(Key, "Query=") == 0) {
     (*rF) >> Line;                               //obtain the query sequence name
     (*rF).ignore(500, '\n');
     strcpy(QKey,"notset");
     if ((*rF).peek()!='\n') {(*rF).get(QKey,8);}
     while (strcmp(QKey,"Length=")!=0) {
      (*rF).ignore(600, '\n');
      if ((*rF).peek()!='\n') {(*rF).get(QKey,8);}
     }
     (*rF) >> Nbp;
     (*rF).get(ch);
     if (ch== ',') {
      Nbp*=1000;
      (*rF).get(ch);
      Nbp+= 100*(ch-48);
      (*rF).get(ch);
      Nbp+= 10*(ch-48);
      (*rF).get(ch);
      Nbp+= (ch-48);
     }
     (*rF).get(ch);
     if (ch== ',') {
      Nbp*=1000;
      (*rF).get(ch);
      Nbp+= 100*(ch-48);
      (*rF).get(ch);
      Nbp+= 10*(ch-48);
      (*rF).get(ch);
      Nbp+= (ch-48);
     }
     (*rF).ignore(600, '\n');
    }
    else if(strcmp(Key,"Lambda")==0) {
     #ifdef DEBUG
     *W << "Lambda case1\n\n";
     #endif
     (*rF).ignore(600,'\n');

     (*rF) >>Lambda_1 >>K_val_1 >>H_val_1;
     (*rF).ignore(600,'\n'); (*rF).ignore(600,'\n');

     if((*rF).peek()=='G') {
      (*rF).ignore(600,'\n'); (*rF).ignore(600,'\n');
      (*rF) >>Lambda_2 >>K_val_2 >>H_val_2;
     }
    }
    else if(strcmp(Key,"Posted")==0) {
     #ifdef DEBUG
     *W << "Posted case1\n\n";
     #endif
     if(retrieve_dbinfo==yes) {
      retrieve_dbinfo = no;
      (*rF).ignore(600,'\n'); (*rF).ignore(100,':');
                                                  //number of letters
      (*rF).getline(Nlet,25); (*rF).ignore(100,':');
      (*rF).getline(Nseq,25);                     //number of sequences

      while((*rF).peek()!='M'&&(*rF).peek() != EOF) {
       if ((*rF).peek()=='L') {
        (*rF) >> Key;
       }
       if(strcmp(Key,"Lambda")==0) {
        (*rF).ignore(600,'\n');
        (*rF) >>Lambda_1 >>K_val_1 >>H_val_1;
        (*rF).ignore(600,'\n');
        if((*rF).peek()=='G') {
         (*rF).ignore(600,'\n'); (*rF).ignore(600,'\n');
         (*rF) >>Lambda_2 >>K_val_2 >>H_val_2;
         (*rF).ignore(600,'\n');
        }
       }
       else
        (*rF).ignore(600,'\n');
      }
      (*rF).getline(Matrix, 50);                  //matrix information
      (*rF).getline(Penalty,80);                  //penalties information
     }                                            //if(retrieve_dbinfo==yes) {
     continue;                                    //return to the loop
    }                                             //if(strcmp(Key,"Posted')==0) {
    else
     (*rF).ignore(1000, '\n');
   } while ((strcmp(Key, "Query=") != 0) && ((*rF).peek() != EOF));

   if ((*rF).peek() == EOF) continue;

   //*****  to retrieve the Query sequence name *****
   C = 0;
   if (Line[0] == 'g' && Line[1] == 'i' && Line[2] == '|') {
    do {
     SQn[C] = Line[C + 3];
     C++;
    } while (C < IDLen && SQn[C - 1] != '|');
    SQn[C - 1] = '\0';
   }
   else {
    for (i = 0; i < strlen(Line); i++) {
     if (Line[i] == '|') {
      C++;
     }
    }
    if (C > 0) {
     i = 0;
     int ii = 0;
     for (int j = 0; j < strlen(Line) - 1; j++) {
      if (Line[j] == '|') {
       i++;
      }
      if (i == C) {
       SQn[ii] = Line[j + 1];
       ii++;
      }
     }
     SQn[ii] = '\0';
    }
    else
     strcpy(SQn, Line);                           //obtain the name of the query
   }

   //*****  Start searching for blast output here   *****
   C = 0;
   Exit = no;                                     //remember the count of hits

   do {
    (*rF) >> Key;
    #ifdef DEBUG
    *W << "\nNow in do loop with Key= " << Key << "\n";
    #endif
    if(strcmp(Key,"Lambda")==0) {
     #ifdef DEBUG
     *W << "Reading Lambda at line 2747\n\n";
     #endif
     (*rF).ignore(600,'\n');

     (*rF) >>Lambda_1 >>K_val_1 >>H_val_1;
     (*rF).ignore(600,'\n'); (*rF).ignore(600,'\n');

     if((*rF).peek()=='G') {
      (*rF).ignore(600,'\n'); (*rF).ignore(600,'\n');
      (*rF) >>Lambda_2 >>K_val_2 >>H_val_2;
     }
    }
    else if(strcmp(Key,"Query=")==0) {
     if (C == 0  &&  Verbose == yes ) {           //print names of non-hitting queries
      if (Rdatafile == yes) {
       int Out = 0;
       switch (OP[0]) {                           //query Length
        case 0: Out = 1; break;
        case 1:
         if (Nbp > QLEN) { Out = 1; }
         else { Out = 0; }
         break;
        case 2:
         if (Nbp >= QLEN) { Out = 1; }
         else { Out = 0; }
         break;
        case 3:
         if (Nbp < QLEN) { Out = 1; }
         else { Out = 0; }
         break;
        case 4:
         if (Nbp <= QLEN) { Out = 1; }
         else { Out = 0; }
         break;
       }
       if (Out == 0) { goto NewQuery; }
      }
      if (Fmt == html) {
       *W << "<A HREF=\"http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Search&db";
       if(BST==blastp || BST==rpsblast || BST==tblastn || BST==rpstblastn) {
        *W << "=Protein&term=" << SQn << "&doptcmdl=GenPept\" target=\"_blank\">";
       }
       else {
        *W << "Nucleotide&term=" << SQn << "&doptcmdl=GenBank\" target=\"_blank\">";
       }
       *W << setiosflags(ios::left) << SQn << "</A>";
      }
      else { *W << setiosflags(ios::left) << SQn; }
      if(strlen(SQn)<QidSize) {
       for(i=0; i<(QidSize+1-strlen(SQn)); i++) { *W << " "; }
      }
      *W << "no_hit";
      for(i=0; i<=QidSize-6; i++) { *W << " "; }
      *W <<resetiosflags(ios::left);
      *W <<setw(5) << Nbp << "\n";
     }                                            //if(Verbose == yes) {
     goto NewQuery;
    }
    if(strcmp(Key,"Sequences")!=0 && strcmp(Key,"Posted")!=0) {
     (*rF).ignore(600,'\n');
    }
   } while(strcmp(Key,"Sequences")!=0 && strcmp(Key,"Posted")!=0 && (*rF).peek()!=EOF);

   if(strcmp(Key,"Posted")==0) {
    #ifdef DEBUG
    *W << "Posted case2\n\n";
    #endif
    if (C == 0  &&  Verbose == yes ) {            //print names of non-hitting queries
     if (Rdatafile == yes) {
      int Out = 0;
      switch (OP[0]) {                            //query Length
       case 0: Out = 1; break;
       case 1:
        if (Nbp > QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (Nbp >= QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (Nbp < QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (Nbp <= QLEN) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { goto NewQuery; }
     }
     if (Fmt == html) {
      *W << "<A HREF=\"http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Search&db";
      if(BST==blastp || BST==rpsblast || BST==tblastn || BST==rpstblastn) {
       *W << "=Protein&term=" << SQn << "&doptcmdl=GenPept\" target=\"_blank\">";
      }
      else {
       *W << "Nucleotide&term=" << SQn << "&doptcmdl=GenBank\" target=\"_blank\">";
      }
      *W << setiosflags(ios::left) << SQn << "</A>";
     }
     else { *W << setiosflags(ios::left) << SQn; }
     if(strlen(SQn)<QidSize) {
      for(i=0; i<(QidSize+1-strlen(SQn)); i++) { *W << " "; }
     }
     *W << "no_hit";
     for(i=0; i<=QidSize-6; i++) { *W << " "; }
     *W <<resetiosflags(ios::left);
     *W <<setw(5) << Nbp << "\n";
    }                                             //if(Verbose == yes) {
    if(retrieve_dbinfo==yes) {
     retrieve_dbinfo = no;
     (*rF).ignore(600,'\n'); (*rF).ignore(100,':');
                                                  //number of letters
     (*rF).getline(Nlet,25); (*rF).ignore(100,':');
     (*rF).getline(Nseq,25);                      //number of sequences

     while((*rF).peek()!='M'&&(*rF).peek() != EOF) {
      if ((*rF).peek()=='L') {
       (*rF) >> Key;
      }
      if(strcmp(Key,"Lambda")==0) {
       (*rF).ignore(600,'\n');
       (*rF) >>Lambda_1 >>K_val_1 >>H_val_1;
       (*rF).ignore(600,'\n');
       if((*rF).peek()=='G') {
        (*rF).ignore(600,'\n'); (*rF).ignore(600,'\n');
        (*rF) >>Lambda_2 >>K_val_2 >>H_val_2;
        (*rF).ignore(600,'\n');
       }
       break;
      }
      else
       (*rF).ignore(600,'\n');
     }
     (*rF).getline(Matrix, 50);                   //matrix information
     (*rF).getline(Penalty,80);                   //penalties information
    }                                             //if(retrieve_dbinfo==yes) {
    continue;                                     //return to the loop
   }                                              //if(strcmp(Key,"Posted')==0) {

   while (C < Nhits && Exit != yes) {
    C++;
    while ((*rF).peek() != '>' && (*rF).peek() != EOF) { (*rF).ignore(2000, '\n'); }

    // Now we have found a line starting with ">", ie a hit record

    gifound = 0;
    getline(*rF, querystring);
    if (querystring.substr(0,0) == " ") {
     keystring = querystring.substr(2,4);
    }                                             // BLAST+-2.2.26
    else {
     keystring = querystring.substr(1,3);
    }                                             // previous BLAST+ versions
    if (keystring.compare(0,3,"gi|") == 0) {      // following the "> " is "gi|"; in this case, we expect a gi number first which we use a the identifier for the subject sequence that gives the hit
     gifound = 1;
     if (querystring.substr(0,0) == " ") {
      querystring = querystring.substr(5);
     }                                            // BLAST+-2.2.26
     else {
      querystring = querystring.substr(4);
     }                                            // previous BLAST+ versions
     foundyou=querystring.find_first_of("| ");    // we find the next "|" and pull out the string up to the "|" as the ID
     if (foundyou!=string::npos) {
      keystring = querystring.substr(0,foundyou);
      strcpy(ID,keystring.c_str());               // check that ID is long enough
      querystring= querystring.substr(foundyou+1);
     }
    }

    // Now we find the database type
    // as per ftp://ftp.ncbi.nih.gov/blast/documents/formatdb.html

    if ((foundyou=querystring.find("gb|")) == 0) {
     Dbase = gb;
     strcpy(DBn, "gb");                           // gb|accession|locus Description
    }
    else if ((foundyou=querystring.find("emb|")) == 0) {
     Dbase = emb;
     strcpy(DBn, "emb");                          // emb|accession|locus Description
    }
    else if ((foundyou=querystring.find("^dbj|")) == 0) {
     Dbase = dbj;
     strcpy(DBn, "dbj");                          // dbj|accession|locus Description
    }
    else if ((foundyou=querystring.find("pir|")) == 0) {
     Dbase = pir;
     strcpy(DBn, "pir");                          // pir||entry Description
    }
    else if ((foundyou=querystring.find("prf|")) == 0) {
     Dbase = prf;
     strcpy(DBn, "prf");                          // prf||name Description
    }
    else if ((foundyou=querystring.find("sp|")) == 0) {
     Dbase = sp;
     strcpy(DBn, "sp");                           // sp|accession|entry_name Description
    }
    else if ((foundyou=querystring.find("pdb|")) == 0) {
     Dbase = pdb;
     strcpy(DBn, "pdb");                          // pdb|entry|chain Description
    }
    else if ((foundyou=querystring.find("pat|")) == 0) {
     Dbase = pat;
     strcpy(DBn, "pat");                          // pat|country|number Description
    }
    else if ((foundyou=querystring.find("bbs|")) == 0) {
     Dbase = bbs;
     strcpy(DBn, "bbs");                          // bbs|number Description
    }
    else if ((foundyou=querystring.find("gnl|")) == 0) {
     Dbase = gnl;
     strcpy(DBn, "gnl");                          // gnl|database|identifier Description
    }
    else if ((foundyou=querystring.find("ref|")) == 0) {
     Dbase = ref;
     strcpy(DBn, "ref");                          // ref|accession|locus Description
    }
    else if ((foundyou=querystring.find("lcl|")) == 0) {
     Dbase = lcl;
     strcpy(DBn, "lcl");                          // lcl|identifier Description
    }
    else if ((foundyou=querystring.find("tpe|")) == 0) {
     Dbase = tpe;
     strcpy(DBn, "tpe");                          // tpe|accession|locus Description
    }
    else {
     Dbase = oth;
     strcpy(DBn, "oth");
    }
    #ifdef DEBUG
    *W << "Dbase type is " << DBn << "\n\n";
    #endif

    //OK, now we need to do the parsing for accession and beginning of description depending on Dbase type

    switch (Dbase) {
     case gb:                                     // "gb|accession|locus Description" parsed as Dbase, ID, Annotation
     case emb:
     case dbj:
     case sp:
     case pdb:
     case ref:
     case tpe:
      // Now we parse the remainder of the string according to the database identifier
      foundyou=querystring.find("|");
      if (foundyou!=string::npos)
       foundfirst = (int)foundyou;
      foundyou=querystring.find("|",foundyou+1);
      if (foundyou!=string::npos)
       keystring = querystring.substr(foundfirst+1,(int)foundyou - foundfirst - 1);
      if (!gifound) strcpy(ID,keystring.c_str()); // we use accession as the subject identifier if the gi number is not available; note that we could make the !gifound a switch to give the user a choice; check that ID is long enough
      foundyou=querystring.find_last_of("|");     // ok, this is tricky: we assume that "descripion" is everything from the last "|" onwards; that would include the "locus" tag if present; need to check what the convention is;
      break;

     case pir:                                    // "pir||entry Description" parsed as Dbase, ID, Annotation
     case prf:
      foundyou=querystring.find("|");
      if (foundyou!=string::npos)
       foundyou=querystring.find("|",foundyou+1);
      if (foundyou!=string::npos)
       foundfirst = foundyou;
      foundyou=querystring.find_first_of(" 	",foundyou+1);
      keystring = querystring.substr(foundfirst+1,(int)foundyou - foundfirst - 1);
      if (!gifound) strcpy(ID,keystring.c_str());
      break;

     case pat:                                    // "pat|country|number Description" parsed as Dbase, ID=country-number, Annotation
      foundyou=querystring.find("|");
      if (foundyou!=string::npos)
       foundfirst = (int)foundyou;
                                                  // find " " or tab
      foundyou=querystring.find_first_of(" 	",foundyou+1);
      if (foundyou!=string::npos)
       keystring = querystring.substr(foundfirst+1,(int)foundyou - foundfirst - 1);
      strcpy(ID,keystring.c_str());
      break;

     case gnl:                                    // "gnl|database|identifier [Description]" parsed as DBase, DBn, ID, Description
      foundyou=querystring.find("|");
      if (foundyou!=string::npos)
       foundfirst = (int)foundyou;
      foundyou=querystring.find("|",foundyou+1);
      if (foundyou!=string::npos)
       keystring = querystring.substr(foundfirst+1,(int)foundyou - foundfirst - 1);
      strcpy(DBn,keystring.c_str());
      foundfirst = (int)foundyou;
                                                  // find " " or tab or |
      foundyou=querystring.find_first_of(" 	|",foundyou+1);
      if (foundyou!=string::npos) {
       keystring = querystring.substr(foundfirst+1,(int)foundyou - foundfirst - 1);
      }
      else {
                                                  // no description provided ...
       keystring = querystring.substr(foundfirst+1);
      }
      strcpy(ID,keystring.c_str());
      break;

     case bbs:                                    // "bbs|number [Description]" parsed as DBase, ID, Description
     case lcl:                                    // "lcl|identifier [Description]" parsed as DBase, ID, Description
      foundyou=querystring.find("|");
      if (foundyou!=string::npos)
       foundfirst = (int)foundyou;
                                                  // find " " or tab
      foundyou=querystring.find_first_of(" 	",foundyou+1);
      if (foundyou!=string::npos) {
       keystring = querystring.substr(foundfirst+1,(int)foundyou - foundfirst - 1);
      }
      else {
                                                  // no description provided ...
       keystring = querystring.substr(foundfirst+1);
      }
      strcpy(ID,keystring.c_str());
      break;

     case oth:                                    // "identifier [Description]" parsed as "other", ID, Description
                                                  // find " " or tab
      foundyou=querystring.find_first_of(" 	",foundyou+1);
      if (foundyou!=string::npos) {
       keystring = querystring.substr(foundfirst+1,(int)foundyou - foundfirst - 1);
      }
      else {
                                                  // no description provided ...
       keystring = querystring.substr(foundfirst+1);
      }
      strcpy(ID,keystring.c_str());
      break;

    }                                             //end of switch(Dbase) {

    if (foundyou!=string::npos) {
     foundyou=querystring.find_first_not_of(" 	",foundyou+1);
     if (foundyou!=string::npos) {
      description= querystring.substr(foundyou);
     }
    }

    // now we add to the description all the input lines until we find the "Length=" line
    getline(*rF, querystring);
    keystring = querystring.substr(0,7);
    while (keystring.compare(0,7,"Length=") != 0) {
     description.append(querystring);
     getline(*rF, querystring);
     keystring = querystring.substr(0,7);
    }

    if (GetSPn == yes) {
     strcpy(SPn,"unknown");                       // unless we find better ...
     foundyou=description.find_first_of("[");     // first we look for [species name]
     if (foundyou!=string::npos) {
      foundfirst = (int)foundyou;
      foundyou=description.find("]",foundyou+1);
      if (foundyou!=string::npos) {
       keystring = description.substr(foundfirst+1,(int)foundyou - foundfirst - 1);
       strcpy(SPn,keystring.c_str());
      }
     }
     if (strcmp(SPn,"unknown")==0) {
      foundyou=description.find("Tax=");          // second try: "Tax=[species name] RepID="
      if (foundyou!=string::npos) {
       foundfirst = (int)foundyou;
       foundyou=description.find("RepID=",foundyou+1);
       if (foundyou!=string::npos) {
        keystring = description.substr(foundfirst+4,(int)foundyou - foundfirst - 4);
        strcpy(SPn,keystring.c_str());
       }
      }
     }
    }

    if (description.size() > AnnColWidthPrt-4) {  // only now we cut the description to the desired print size
     description= description.substr(0,AnnColWidthPrt-3);
     strcpy(Annotation,description.c_str());
     Annotation[AnnColWidthPrt-3] = '.';
     Annotation[AnnColWidthPrt-2] = '.';
     Annotation[AnnColWidthPrt-1] = '.';
     Annotation[AnnColWidthPrt] = '\0';
    }
    else {
     description= description.substr(0,AnnColWidthPrt-1);
     if (description.size() == 0) {
      strcpy(Annotation,"n/a");
     }
     else {
      strcpy(Annotation,description.c_str());
     }
    }

    strcpy(queryarray,querystring.c_str());       // check length
    sscanf(queryarray,"Length=%ld",&FLen);        // now we get the sequence length and that's it

    #ifdef DEBUG
    *W << "\nDbase is " << Dbase << "; GetSPn is " << GetSPn << " and Annotation is " << Annotation << "\n";
    #endif
    (*rF).ignore(500, '\n');                      // don't need anything else on that line

    //Onwards: now we finally parse the hit

    HSP = 0;                                      // indexing the HSPs by the HSP counter
    while ((*rF).peek() != '>' && Exit!=yes && (*rF).peek() != EOF) {
     (*rF) >> Key;
     #ifdef DEBUG
     *W << "\nHere my Key is " << Key << endl;
     #endif
     if (strcmp(Key,"Query=")==0) {goto NewQuery;}
     if (strcmp(Key,"BLASTX")==0 || strcmp(Key, "BLASTN")==0 || strcmp(Key,"BLASTP")==0 ||
      strcmp(Key,"TBLASTN")==0 || strcmp(Key,"TBLASTX")==0)                             {Exit= yes;}
     if (strcmp(Key, "Score") == 0) {
      if (HSP >= MaxHSPs) {
       cout << "\nThe comparison '" << SQn << "' versus '" << Annotation << "' produced too many HSPs.\n" <<
        "Please check the BLAST output and if all right, increase the MaxHSPs definition in MuSeqBox.C and recompile.\n" <<
        "[current value of MaxHSPs: " << MaxHSPs << "]\n";
       exit(0);
      }
      (*rF).ignore(40, '=');
      (*rF) >> SD.Score[HSP];                     //bit score
      (*rF).ignore(40, '=');
      (*rF) >> SD.E[HSP];
      (*rF).ignore(600, '\n');                    //evalue
      i = 0;
      while (i<8) {                               // removing any trailing ',' from the evalue capture
       if (SD.E[HSP][i] == ',') {SD.E[HSP][i] = '\0'; break;}
       ++i;
      }
      if (SD.E[HSP][0] == 'e') {
       strcpy(Key, SD.E[HSP]);
       strcpy(SD.E[HSP], "1");
       strcat(SD.E[HSP], Key);
      }
      (*rF).ignore(40, '=');
      (*rF) >> SD.Iden[HSP];                      //identity

      (*rF).get(ch);
      (*rF) >> Len;

      switch (BST) {
       case blastx:
       case tblastn: case rpstblastn:
        (*rF).ignore(40, '=');
        (*rF) >> SD.Simi[HSP];
        (*rF).ignore(50, ')');
        if((*rF).peek()==',') {
         (*rF).ignore(50,'=');
         (*rF) >>SD.Gaps[HSP];
        }
        else { SD.Gaps[HSP]=0; }
        (*rF).ignore(100,'=');
        (*rF) >>SD.Frame[HSP];
        break;
       case tblastx:
        (*rF).ignore(40, '=');
        (*rF) >> SD.Simi[HSP];
        (*rF).ignore(50, ')');
        if((*rF).peek()==',') {
         (*rF).ignore(50,'=');
         (*rF) >>SD.Gaps[HSP];
        }
        else { SD.Gaps[HSP]=0; }
        (*rF).ignore(100, '=');
        (*rF) >>SD.Frame[HSP];
        break;
       case blastp: case rpsblast:
        (*rF).ignore(50,'=');
        (*rF) >> SD.Simi[HSP];
        (*rF).ignore(50,')');
        if((*rF).peek()==',') {
         (*rF).ignore(50,'=');
         (*rF) >>SD.Gaps[HSP];
        }
        else { SD.Gaps[HSP]=0; }
        strcpy(SD.Frame[HSP], "n/a");
        break;
       case blastn:
        (*rF).ignore(50,')');
        if((*rF).peek()==',') {
         (*rF).ignore(50,'=');
         (*rF) >>SD.Gaps[HSP];
        }
        else { SD.Gaps[HSP]=0; }
        (*rF).ignore(200, '=');
        (*rF) >> Line;

        if (strcmp(Line, "Plus/Plus") == 0) {
         strcpy(SD.Frame[HSP], "+/+");
        }
        else if (strcmp(Line, "Plus/Minus") == 0) {
         strcpy(SD.Frame[HSP], "+/-");
        }
        else if (strcmp(Line, "Minus/Plus") == 0) {
         strcpy(SD.Frame[HSP], "-/+");
        }
        else if (strcmp(Line, "Minus/Minus") == 0) {
         strcpy(SD.Frame[HSP], "-/-");
        }
        else {
         strcpy(SD.Frame[HSP], "?/?");
        }
        break;
      }
      SD.SCov[HSP] = 1.0 * Len / FLen * 100.0;    //coverage
      SD.Iden[HSP] = SD.Iden[HSP] / Len * 100.0;  //identity

      switch (BST) {
       case blastx:
       case blastp: case rpsblast:
        SD.Simi[HSP] = SD.Simi[HSP] / Len * 100.0;//similarity
        break;
       case tblastn: case rpstblastn:
       case tblastx:
        SD.SCov[HSP] = SD.SCov[HSP]*3;
        SD.Simi[HSP] = SD.Simi[HSP] / Len * 100.0;//similarity
        break;
       case blastn:
        break;
      }

      lst = yes;
      while ((*rF).peek() != 'Q' && (*rF).peek() != EOF) {
       (*rF).ignore(600, '\n');
      }
      do {
       (*rF) >> Key;
       if (strcmp(Key,"Query=")==0) {Exit = yes; break;}
       switch (lst) {
        case yes:
         (*rF) >> SD.XYq[HSP][0];
         if (SD.XYq[HSP][0] < 10) {
          NC = 1;
         }
         if (SD.XYq[HSP][0] >= 10 && SD.XYq[HSP][0] < 100) {
          NC = 2;
         }
         if (SD.XYq[HSP][0] >= 100 && SD.XYq[HSP][0] < 1000) {
          NC = 3;
         }
         if (SD.XYq[HSP][0] >= 1000 && SD.XYq[HSP][0] < 10000) {
          NC = 4;
         }
         if (SD.XYq[HSP][0] >= 10000 && SD.XYq[HSP][0] < 100000) {
          NC = 5;
         }
         if (SD.XYq[HSP][0] >= 100000) {
          NC = 6;
         }
         while ((*rF).peek() == ' ') {
          (*rF).get(ch);
          NC = NC + 1;
         }
         (*rF).ignore(600, ' ');
         (*rF) >> SD.XYq[HSP][1];
         (*rF).ignore(600, '\n');
         (*rF).ignore(600, '\n');
         (*rF).ignore(40, 't');
         (*rF) >> SD.XYs[HSP][0];
         while ((*rF).peek() == ' ')
          (*rF).get(ch);
         (*rF).ignore(600, ' ');
         (*rF) >> SD.XYs[HSP][1];
         (*rF).ignore(600, '\n');
         lst = no;
         break;
        case no:
         for (i = 0; i < 2 + NC; i++)
          (*rF).get(ch);
         (*rF).ignore(600, ' ');
         (*rF) >> SD.XYq[HSP][1];
         (*rF).ignore(600, '\n');
         (*rF).ignore(600, '\n');
         for (i = 0; i < 8 + NC; i++)
          (*rF).get(ch);
         (*rF).ignore(600, ' ');
         (*rF) >> SD.XYs[HSP][1];
         (*rF).ignore(600, '\n');
         break;
       }
       for (i = 0; i < 2; i++) {                  //IGNORE EMPTY LINES
        if ((*rF).peek() == '\n' || (*rF).peek() == ' ' ||
        (*rF).peek() == '\t'  ||  (*rF).peek() == '\r') {
         (*rF).ignore(1000, '\n');
        }
       }
      } while ((*rF).peek() == 'Q');
      SD.QCov[HSP] =100.0 * (abs(SD.XYq[HSP][1] - SD.XYq[HSP][0]) + 1) / (1.0 * Nbp);
      ++HSP;
     }                                            //if(strcmp(Key, "Score")==0) {
     else if(strcmp(Key, "Lambda")==0) {
      (*rF).ignore(600,'\n');
      #ifdef DEBUG
      *W << "\nReading Lambda at line 3889\n";
      #endif

      (*rF) >>Lambda_1 >>K_val_1 >>H_val_1;
      (*rF).ignore(600,'\n'); (*rF).ignore(600,'\n');

      if((*rF).peek()=='G') {
       (*rF).ignore(600,'\n'); (*rF).ignore(600,'\n');
       (*rF) >>Lambda_2 >>K_val_2 >>H_val_2;
      }
      Exit=yes;
     }                                            //if(strcmp(Key,"Score")==0) { } else { }
     else {
      if(strcmp(Key, "Posted")==0) {
       #ifdef DEBUG
       *W << "Posted case3\n\n";
       #endif
       if(retrieve_dbinfo==yes) {
        retrieve_dbinfo = no;
        (*rF).ignore(600,'\n'); (*rF).ignore(100,':');
                                                  //number of letters
        (*rF).getline(Nlet,25); (*rF).ignore(100,':');
        (*rF).getline(Nseq,25);                   //number of sequences

        while((*rF).peek()!='M'&&(*rF).peek() != EOF) {
         if ((*rF).peek()=='L') {
          (*rF) >> Key;
         }
         if(strcmp(Key,"Lambda")==0) {
          #ifdef DEBUG
          *W << "Lambda case3\n\n";
          #endif
          (*rF).ignore(600,'\n');
          (*rF) >>Lambda_1 >>K_val_1 >>H_val_1;
          (*rF).ignore(600,'\n');
          if((*rF).peek()=='G') {
           (*rF).ignore(600,'\n'); (*rF).ignore(600,'\n');
           (*rF) >>Lambda_2 >>K_val_2 >>H_val_2;
           (*rF).ignore(600,'\n');
          }
          break;
         }
         else
          (*rF).ignore(600,'\n');
        }
        (*rF).getline(Matrix, 50);                //matrix information
        (*rF).getline(Penalty,80);                //penalties information
       }                                          //if(retrieve_dbinfo==yes) {
       Exit=yes;
      }                                           //if(strcmp(Key, "Posted")==0) {
      else { (*rF).ignore(600, '\n'); }
     }                                            //if(strcmp(Key,"Score")==0) { } else { }
    }                                             //while((*rF).peek()!='>' && Exit!=yes)

    if(C>Nhits && retrieve_dbinfo==yes) {
     do {
      (*rF) >> Key;
      if (strcmp(Key,"Query=")==0) {goto NewQuery;}
      if(strcmp(Key, "Posted") !=0) { (*rF).ignore(600, '\n'); }
     } while(strcmp(Key,"Posted")!=0 && (*rF).peek() != EOF);
     retrieve_dbinfo=no;

     (*rF).ignore(600,'\n'); (*rF).ignore(100,':');
                                                  //number of letters
     (*rF).getline(Nlet,25); (*rF).ignore(100,':');
     (*rF).getline(Nseq,25);                      //number of sequences

     while((*rF).peek()!='M'&&(*rF).peek() != EOF) {
      (*rF) >> Key;
      if(strcmp(Key,"Lambda")==0) {
       #ifdef DEBUG
       *W << "Lambda case4\n\n";
       #endif
       (*rF).ignore(600,'\n');
       (*rF) >>Lambda_1 >>K_val_1 >>H_val_1;
       (*rF).ignore(600,'\n');
       if((*rF).peek()=='G') {
        (*rF).ignore(600,'\n'); (*rF).ignore(600,'\n');
        (*rF) >>Lambda_2 >>K_val_2 >>H_val_2;
        (*rF).ignore(600,'\n');
       }
       break;
      }
      else
       (*rF).ignore(600,'\n');
     }
     (*rF).getline(Matrix, 50);                   //matrix information
     (*rF).getline(Penalty,80);                   //penalties information
    }

    if (Rdatafile == yes) {
     int Out = 0, LEN;
     double Eval;
     for (j = 0; j < HSP; j++) {
      switch (OP[0]) {                            //query Length
       case 0: Out = 1; break;
       case 1:
        if (Nbp > QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (Nbp >= QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (Nbp < QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (Nbp <= QLEN) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      LEN = abs(SD.XYq[j][0] - SD.XYq[j][1]) + 1; //HSP length
      switch (OP[1]) {
       case 0: Out = 1; break;
       case 1:
        if (LEN > HLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (LEN >= HLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (LEN < HLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (LEN <= HLEN) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[2]) {                            //subject length
       case 0: Out = 1; break;
       case 1:
        if (FLen > SLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (FLen >= SLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (FLen < SLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (FLen <= SLEN) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[3]) {                            //percent coverage
       case 0: Out = 1; break;
       case 1:
        if (SD.SCov[j] > SCOV) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (SD.SCov[j] >= SCOV) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (SD.SCov[j] < SCOV) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (SD.SCov[j] <= SCOV) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[4]) {                            //query coverage
       case 0: Out = 1; break;
       case 1:
        if (SD.QCov[j] > QCOV) {  Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (SD.QCov[j] >= QCOV) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (SD.QCov[j] < QCOV) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (SD.QCov[j] <= QCOV) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[5]) {                            //percent identity
       case 0: Out = 1; break;
       case 1:
        if (SD.Iden[j] > IDEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (SD.Iden[j] >= IDEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (SD.Iden[j] < IDEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (SD.Iden[j] <= IDEN) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[6]) {                            //number of gaps
       case 0: Out = 1; break;
       case 1:
        if (SD.Gaps[j] > GAPS) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (SD.Gaps[j] >= GAPS) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (SD.Gaps[j] < GAPS) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (SD.Gaps[j] <= GAPS) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[7]) {                            //alignment score
       case 0: Out = 1; break;
       case 1:
        if (SD.Score[j] > SCOR) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (SD.Score[j] >= SCOR) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (SD.Score[j] < SCOR) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (SD.Score[j] <= SCOR) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      Eval = atof(SD.E[j]);                       //expected value
      switch (OP[8]) {
       case 0: Out = 1; break;
       case 1:
        if (Eval > EVAL) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (Eval >= EVAL) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (Eval < EVAL) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (Eval <= EVAL) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) {
       continue;
      }
      else {
       break;
      }
     }
     if (Out == 1) {
      if(Fmt==html) {
       if(bgc==0) {
        bgc=2;
       }
       else {
        bgc=0;
       }
      }
      print(W, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, Nhsps, SD, Fmt, BST, Pstyle, bgc);

      if (OutputChimeras == yes) {
       if (C == 1) {
        chimera = 0;
        strcpy(SQf,ID); XYfh[0] = SD.XYq[0][0]; XYfh[1] = SD.XYq[0][1]; strcpy(Hit1,Annotation);
        if (XYfh[0] <= XYfh[1]) {
         for (i=1;i<HSP;++i) {
          if (SD.XYq[i][0] <= SD.XYq[i][1]) {     // only look at HSPs of orientation matching the orientation of the highest scoring HSP
           if (SD.XYq[i][0] < XYfh[0]) {XYfh[0] = SD.XYq[i][0];}
           if (SD.XYq[i][1] > XYfh[1]) {XYfh[1] = SD.XYq[i][1];}
          }
         }
        }
        else {
         for (i=1;i<HSP;++i) {
          if (SD.XYq[i][0] > SD.XYq[i][1]) {      // only look at HSPs of orientation matching the orientation of the highest scoring HSP
           if (SD.XYq[i][0] > XYfh[0]) {XYfh[0] = SD.XYq[i][0];}
           if (SD.XYq[i][1] < XYfh[1]) {XYfh[1] = SD.XYq[i][1];}
          }
         }
        }
        for (i=strlen(Hit1)-1;i>=0;--i) {
         if (Hit1[i]==' ') {
          Hit1[i]='\0';
         }
         else {
          break;
         }
        }
       }
       else {
        XYsh[0] = SD.XYq[0][0]; XYsh[1] = SD.XYq[0][1]; strcpy(Hit2,Annotation);
        if (XYsh[0] <= XYsh[1]) {
         for (i=1;i<HSP;++i) {
          if (SD.XYq[i][0] <= SD.XYq[i][1]) {     // only look at HSPs of orientation matching the orientation of the highest scoring HSP
           if (SD.XYq[i][0] < XYsh[0]) {XYsh[0] = SD.XYq[i][0];}
           if (SD.XYq[i][1] > XYsh[1]) {XYsh[1] = SD.XYq[i][1];}
          }
         }
        }
        else {
         for (i=1;i<HSP;++i) {
          if (SD.XYq[i][0] > SD.XYq[i][1]) {      // only look at HSPs of orientation matching the orientation of the highest scoring HSP
           if (SD.XYq[i][0] > XYsh[0]) {XYsh[0] = SD.XYq[i][0];}
           if (SD.XYq[i][1] < XYsh[1]) {XYsh[1] = SD.XYq[i][1];}
          }
         }
        }
        for (i=strlen(Hit2)-1;i>=0;--i) {
         if (Hit2[i]==' ') {
          Hit2[i]='\0';
         }
         else {
          break;
         }
        }
        if (XYfh[0] <= XYfh[1]) {
         if (XYsh[0] >= XYfh[1]-MaxOverlap  &&  XYsh[1]>=XYfh[1]+MinExtension) {
          if (chimera == 0 ) {
           if (XYsh[0] < XYsh[1]) {
            strcpy(chimeratype,"++");
           }
           else {
            strcpy(chimeratype,"+-");
           }
           *W << "\n  !Potential chimera" << chimeratype << ": Query " << SQn << " matches " << SQf << " (" << Hit1 << ") from " << XYfh[0] << " to " << XYfh[1] << " and " << ID << " (" << Hit2 << ") from " << XYsh[0] << " to " << XYsh[1] << ".\n\n";
           chimera = 1;
          }
         }
        }
        else {
         if (XYsh[0] <= XYfh[1]+MaxOverlap  &&  XYsh[1]<=XYfh[1]-MinExtension) {
          if (chimera == 0 ) {
           if (XYsh[0] < XYsh[1]) {
            strcpy(chimeratype,"-+");
           }
           else {
            strcpy(chimeratype,"--");
           }
           *W << "\n  !Potential chimera" << chimeratype << ": Query " << SQn << " matches " << SQf << " (" << Hit1 << ") from " << XYfh[0] << " to " << XYfh[1] << " and " << ID << " (" << Hit2 << ") from " << XYsh[0] << " to " << XYsh[1] << ".\n\n";
           chimera = 1;
          }
         }
        }
       }                                          // end of C>1 case
      }                                           // OutputChimeras

     }
    }
    else {
     if(cc==1) {
      bgc=0;
     }
     if(Fmt==html) {
      if(bgc==0) {
       bgc=2;
      }
      else {
       bgc=0;
      }
     }
     print(W, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, Nhsps, SD, Fmt, BST, Pstyle, bgc);

     if (OutputChimeras == yes) {
      if (C == 1) {
       chimera = 0;
       strcpy(SQf,ID); XYfh[0] = SD.XYq[0][0]; XYfh[1] = SD.XYq[0][1]; strcpy(Hit1,Annotation);
       if (XYfh[0] <= XYfh[1]) {
        for (i=1;i<HSP;++i) {
         if (SD.XYq[i][0] <= SD.XYq[i][1]) {      // only look at HSPs of orientation matching the orientation of the highest scoring HSP
          if (SD.XYq[i][0] < XYfh[0]) {XYfh[0] = SD.XYq[i][0];}
          if (SD.XYq[i][1] > XYfh[1]) {XYfh[1] = SD.XYq[i][1];}
         }
        }
       }
       else {
        for (i=1;i<HSP;++i) {
         if (SD.XYq[i][0] > SD.XYq[i][1]) {       // only look at HSPs of orientation matching the orientation of the highest scoring HSP
          if (SD.XYq[i][0] > XYfh[0]) {XYfh[0] = SD.XYq[i][0];}
          if (SD.XYq[i][1] < XYfh[1]) {XYfh[1] = SD.XYq[i][1];}
         }
        }
       }
       for (i=strlen(Hit1)-1;i>=0;--i) {
        if (Hit1[i]==' ') {
         Hit1[i]='\0';
        }
        else {
         break;
        }
       }
      }
      else {
       XYsh[0] = SD.XYq[0][0]; XYsh[1] = SD.XYq[0][1]; strcpy(Hit2,Annotation);
       if (XYsh[0] <= XYsh[1]) {
        for (i=1;i<HSP;++i) {
         if (SD.XYq[i][0] <= SD.XYq[i][1]) {      // only look at HSPs of orientation matching the orientation of the highest scoring HSP
          if (SD.XYq[i][0] < XYsh[0]) {XYsh[0] = SD.XYq[i][0];}
          if (SD.XYq[i][1] > XYsh[1]) {XYsh[1] = SD.XYq[i][1];}
         }
        }
       }
       else {
        for (i=1;i<HSP;++i) {
         if (SD.XYq[i][0] > SD.XYq[i][1]) {       // only look at HSPs of orientation matching the orientation of the highest scoring HSP
          if (SD.XYq[i][0] > XYsh[0]) {XYsh[0] = SD.XYq[i][0];}
          if (SD.XYq[i][1] < XYsh[1]) {XYsh[1] = SD.XYq[i][1];}
         }
        }
       }
       for (i=strlen(Hit2)-1;i>=0;--i) {
        if (Hit2[i]==' ') {
         Hit2[i]='\0';
        }
        else {
         break;
        }
       }
       if (XYfh[0] <= XYfh[1]) {
        if (XYsh[0] >= XYfh[1]-MaxOverlap  &&  XYsh[1]>=XYfh[1]+MinExtension) {
         if (chimera == 0 ) {
          if (XYsh[0] < XYsh[1]) {
           strcpy(chimeratype,"++");
          }
          else {
           strcpy(chimeratype,"+-");
          }
          *W << "\n  !Potential chimera" << chimeratype << ": Query " << SQn << " matches " << SQf << " (" << Hit1 << ") from " << XYfh[0] << " to " << XYfh[1] << " and " << ID << " (" << Hit2 << ") from " << XYsh[0] << " to " << XYsh[1] << ".\n\n";
          chimera = 1;
         }
        }
       }
       else {
        if (XYsh[0] <= XYfh[1]+MaxOverlap  &&  XYsh[1]<=XYfh[1]-MinExtension) {
         if (chimera == 0 ) {
          if (XYsh[0] < XYsh[1]) {
           strcpy(chimeratype,"-+");
          }
          else {
           strcpy(chimeratype,"--");
          }
          *W << "\n  !Potential chimera" << chimeratype << ": Query " << SQn << " matches " << SQf << " (" << Hit1 << ") from " << XYfh[0] << " to " << XYfh[1] << " and " << ID << " (" << Hit2 << ") from " << XYsh[0] << " to " << XYsh[1] << ".\n\n";
          chimera = 1;
         }
        }
       }
      }                                           // end of C>1 case
     }                                            // OutputChimeras

     cc=cc+1;
    }
    (*W).flush();

    if (wG) {                                     //potential full-length CDS
     FullCDs(&wG, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, SD, Fmt, BST, Pstyle, Gc, Startq, Endq);
    }

    if (wI && HSP > 1) {                          //potential alternatively spliced transcript
     AltSplicing(&wI, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, SD, Fmt, BST, Pstyle, Ic);
    }

    if(wR && HSP > 1) {                           //query sequence which may contain repeat segments
     Repeats(&wR, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, SD, Fmt, BST, Pstyle, Rc);
    }

    if (wH) {                                     //sequence similar to the annotated subject sequence
     Homolog(&wH, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, SD, Fmt, BST, Pstyle, Hc);
    }

   }                                              //end of while(C<Nhits && (*rF).peek()!==EOF && Exit!=yes)
   if (strcmp(Key,"Query=")==0) {goto NewQuery;}
  }                                               //end of while((*rF).peek()!=EOF) {
 }                                                //end of if(Ftype==blast) {

 else {                                           //Ftype==parsed: input parsed file created by MuSeqBox
  strcpy(Key, "  ");
  C = 0;

  while ((*rF).peek() !='-' && (*rF).peek() !=EOF) {
   (*rF) >> SQn;
   if (strcmp(SQn, "!Potential") == 0) {(*rF).ignore(500, '\n'); continue;}
   if (strcmp(SQn, Key) == 0) { C++; }
   else {
    strcpy(Key, SQn);
    C = 1;
   }

   if( C>Nhits) { (*rF).ignore(600, '\n'); continue; }
   else {
    (*rF) >>ID >>Nbp;
    if (strcmp(ID,"no_hit")==0) {
     if (Rdatafile == yes) {
      int Out = 0;
      switch (OP[0]) {                            //query length
       case 0: Out = 1; break;
       case 1:
        if (Nbp > QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (Nbp >= QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (Nbp < QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (Nbp <= QLEN) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }
     }
     if (Verbose == yes) {
      if (Fmt == html) {
       *W << "<A HREF=\"http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Search&db";
       if(BST==blastp || BST==rpsblast || BST==tblastn || BST==rpstblastn) {
        *W << "=Protein&term=" << SQn << "&doptcmdl=GenPept\" target=\"_blank\">";
       }
       else {
        *W << "Nucleotide&term=" << SQn << "&doptcmdl=GenBank\" target=\"_blank\">";
       }
       *W << setiosflags(ios::left) << SQn << "</A>";
      }
      else { *W << setiosflags(ios::left) << SQn; }
      if(strlen(SQn)<QidSize) {
       for(i=0; i<(QidSize+1-strlen(SQn)); i++) { *W << " "; }
      }
      *W << "no_hit";
      for(i=0; i<=QidSize-6; i++) { *W << " "; }
      *W <<resetiosflags(ios::left);
      *W <<setw(5) << Nbp << "\n";
     }                                            //if(Verbose == yes) {
     (*rF).ignore(600, '\n');
     continue;
    }                                             //end of no_hit
    else {
     (*rF) >>NC;                                  //count of HSPs
     (*rF).get(ch);
     (*rF) >>HSP >>Len >>SD.QCov[0] >>SD.XYq[0][0] >>SD.XYq[0][1];
     (*rF) >>SD.XYs[0][0] >>SD.XYs[0][1] >>FLen >>SD.SCov[0] >>SD.Iden[0];

     switch(BST) {
      case blastx: case blastp: case rpsblast: case tblastn: case rpstblastn: case tblastx:
       (*rF) >>SD.Simi[0] >>SD.Gaps[0];
       break;
      case blastn:
       (*rF) >>SD.Gaps[0];
       break;
     }

     if(BST != blastp && BST != rpsblast) { (*rF) >>SD.Frame[0]; }
     (*rF) >>SD.Score[0] >>SD.E[0] >>DBn;

     while((*rF).peek() == ' ') { (*rF).get(ch); }
     (*rF).get(Annotation, AnnColWidthPrt+1);     //get the annotation
     if (GetSPn == yes) {
      while((*rF).peek() == ' ') { (*rF).get(ch); }
      (*rF).get(SPn, SrcSize+1);                  //get the species name ("Source")
     }
     (*rF).ignore(200,'\n');
    }

    for (i=1; i<HSP; i++) {
     (*rF).ignore(200, '/');
     (*rF).ignore(20, ' ');
     (*rF) >>Len >>SD.QCov[i] >>SD.XYq[i][0] >>SD.XYq[i][1];
     (*rF) >>SD.XYs[i][0] >>SD.XYs[i][1] >>FLen >>SD.SCov[i] >>SD.Iden[i];

     switch(BST) {
      case blastx: case blastp: case rpsblast: case tblastn: case rpstblastn: case tblastx:
       (*rF) >>SD.Simi[i] >>SD.Gaps[i];
       break;
      case blastn:
       (*rF) >>SD.Gaps[i];
       break;
     }

     if(BST != blastp && BST != rpsblast) { (*rF) >>SD.Frame[i]; }
     (*rF) >>SD.Score[i] >>SD.E[i];
     (*rF).ignore(600, '\n');
    }

    if (Rdatafile == yes) {
     int Out = 0, LEN;
     double Eval;
     for (j = 0; j < HSP; j++) {
      switch (OP[0]) {                            //query length
       case 0: Out = 1; break;
       case 1:
        if (Nbp > QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (Nbp >= QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (Nbp < QLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (Nbp <= QLEN) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      LEN = abs(SD.XYq[j][0] - SD.XYq[j][1]) + 1; //HSP length
      switch (OP[1]) {
       case 0: Out = 1; break;
       case 1:
        if (LEN > HLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (LEN >= HLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (LEN < HLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (LEN <= HLEN) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[2]) {                            //subject length
       case 0: Out = 1; break;
       case 1:
        if (FLen > SLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (FLen >= SLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (FLen < SLEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (FLen <= SLEN) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[3]) {                            //percent coverage
       case 0: Out = 1; break;
       case 1:
        if (SD.SCov[j] > SCOV) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (SD.SCov[j] >= SCOV) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (SD.SCov[j] < SCOV) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (SD.SCov[j] <= SCOV) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[4]) {                            //query coverage
       case 0: Out = 1; break;
       case 1:
        if (SD.QCov[j] > QCOV) {  Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (SD.QCov[j] >= QCOV) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (SD.QCov[j] < QCOV) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (SD.QCov[j] <= QCOV) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[5]) {                            //percent identity
       case 0: Out = 1; break;
       case 1:
        if (SD.Iden[j] > IDEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (SD.Iden[j] >= IDEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (SD.Iden[j] < IDEN) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (SD.Iden[j] <= IDEN) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[6]) {                            //number of gaps
       case 0: Out = 1; break;
       case 1:
        if (SD.Gaps[j] > GAPS) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (SD.Gaps[j] >= GAPS) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (SD.Gaps[j] < GAPS) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (SD.Gaps[j] <= GAPS) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      switch (OP[7]) {                            //alignment score
       case 0: Out = 1; break;
       case 1:
        if (SD.Score[j] > SCOR) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (SD.Score[j] >= SCOR) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (SD.Score[j] < SCOR) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (SD.Score[j] <= SCOR) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }

      Eval = atof(SD.E[j]);                       //expected value
      switch (OP[8]) {
       case 0: Out = 1; break;
       case 1:
        if (Eval > EVAL) { Out = 1; }
        else { Out = 0; }
        break;
       case 2:
        if (Eval >= EVAL) { Out = 1; }
        else { Out = 0; }
        break;
       case 3:
        if (Eval < EVAL) { Out = 1; }
        else { Out = 0; }
        break;
       case 4:
        if (Eval <= EVAL) { Out = 1; }
        else { Out = 0; }
        break;
      }
      if (Out == 0) { continue; }
      else { break; }
     }
     if (Out == 1) {
      if(Fmt==html) {
       if(bgc==0) {
        bgc=2;
       }
       else {
        bgc=0;
       }
      }
      print(W, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, Nhsps, SD, Fmt, BST, Pstyle, bgc);

      if (OutputChimeras == yes) {
       if (C == 1) {
        chimera = 0;
        strcpy(SQf,ID); XYfh[0] = SD.XYq[0][0]; XYfh[1] = SD.XYq[0][1]; strcpy(Hit1,Annotation);
        if (XYfh[0] <= XYfh[1]) {
         for (i=1;i<HSP;++i) {
          if (SD.XYq[i][0] <= SD.XYq[i][1]) {     // only look at HSPs of orientation matching the orientation of the highest scoring HSP
           if (SD.XYq[i][0] < XYfh[0]) {XYfh[0] = SD.XYq[i][0];}
           if (SD.XYq[i][1] > XYfh[1]) {XYfh[1] = SD.XYq[i][1];}
          }
         }
        }
        else {
         for (i=1;i<HSP;++i) {
          if (SD.XYq[i][0] > SD.XYq[i][1]) {      // only look at HSPs of orientation matching the orientation of the highest scoring HSP
           if (SD.XYq[i][0] > XYfh[0]) {XYfh[0] = SD.XYq[i][0];}
           if (SD.XYq[i][1] < XYfh[1]) {XYfh[1] = SD.XYq[i][1];}
          }
         }
        }
        for (i=strlen(Hit1)-1;i>=0;--i) {
         if (Hit1[i]==' ') {
          Hit1[i]='\0';
         }
         else {
          break;
         }
        }
       }
       else {
        XYsh[0] = SD.XYq[0][0]; XYsh[1] = SD.XYq[0][1]; strcpy(Hit2,Annotation);
        if (XYsh[0] <= XYsh[1]) {
         for (i=1;i<HSP;++i) {
          if (SD.XYq[i][0] <= SD.XYq[i][1]) {     // only look at HSPs of orientation matching the orientation of the highest scoring HSP
           if (SD.XYq[i][0] < XYsh[0]) {XYsh[0] = SD.XYq[i][0];}
           if (SD.XYq[i][1] > XYsh[1]) {XYsh[1] = SD.XYq[i][1];}
          }
         }
        }
        else {
         for (i=1;i<HSP;++i) {
          if (SD.XYq[i][0] > SD.XYq[i][1]) {      // only look at HSPs of orientation matching the orientation of the highest scoring HSP
           if (SD.XYq[i][0] > XYsh[0]) {XYsh[0] = SD.XYq[i][0];}
           if (SD.XYq[i][1] < XYsh[1]) {XYsh[1] = SD.XYq[i][1];}
          }
         }
        }
        for (i=strlen(Hit2)-1;i>=0;--i) {
         if (Hit2[i]==' ') {
          Hit2[i]='\0';
         }
         else {
          break;
         }
        }
        if (XYfh[0] <= XYfh[1]) {
         if (XYsh[0] >= XYfh[1]-MaxOverlap  &&  XYsh[1]>=XYfh[1]+MinExtension) {
          if (chimera == 0 ) {
           if (XYsh[0] < XYsh[1]) {
            strcpy(chimeratype,"++");
           }
           else {
            strcpy(chimeratype,"+-");
           }
           *W << "\n  !Potential chimera" << chimeratype << ": Query " << SQn << " matches " << SQf << " (" << Hit1 << ") from " << XYfh[0] << " to " << XYfh[1] << " and " << ID << " (" << Hit2 << ") from " << XYsh[0] << " to " << XYsh[1] << ".\n\n";
           chimera = 1;
          }
         }
        }
        else {
         if (XYsh[0] <= XYfh[1]+MaxOverlap  &&  XYsh[1]<=XYfh[1]-MinExtension) {
          if (chimera == 0 ) {
           if (XYsh[0] < XYsh[1]) {
            strcpy(chimeratype,"-+");
           }
           else {
            strcpy(chimeratype,"--");
           }
           *W << "\n  !Potential chimera" << chimeratype << ": Query " << SQn << " matches " << SQf << " (" << Hit1 << ") from " << XYfh[0] << " to " << XYfh[1] << " and " << ID << " (" << Hit2 << ") from " << XYsh[0] << " to " << XYsh[1] << ".\n\n";
           chimera = 1;
          }
         }
        }
       }                                          // end of C>1 case
      }                                           // OutputChimeras

     }
    }
    else {                                        // Rdatafile == 0 case
     if(cc==1){bgc=0;}
     if(Fmt==html) {
      if(bgc==0) {
       bgc=2;
      }
      else {
       bgc=0;
      }
     }
     print(W, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, Nhsps, SD, Fmt, BST, Pstyle,bgc);

     if (OutputChimeras == yes) {
      if (C == 1) {
       chimera = 0;
       strcpy(SQf,ID); XYfh[0] = SD.XYq[0][0]; XYfh[1] = SD.XYq[0][1]; strcpy(Hit1,Annotation);
       if (XYfh[0] <= XYfh[1]) {
        for (i=1;i<HSP;++i) {
         if (SD.XYq[i][0] <= SD.XYq[i][1]) {      // only look at HSPs of orientation matching the orientation of the highest scoring HSP
          if (SD.XYq[i][0] < XYfh[0]) {XYfh[0] = SD.XYq[i][0];}
          if (SD.XYq[i][1] > XYfh[1]) {XYfh[1] = SD.XYq[i][1];}
         }
        }
       }
       else {
        for (i=1;i<HSP;++i) {
         if (SD.XYq[i][0] > SD.XYq[i][1]) {       // only look at HSPs of orientation matching the orientation of the highest scoring HSP
          if (SD.XYq[i][0] > XYfh[0]) {XYfh[0] = SD.XYq[i][0];}
          if (SD.XYq[i][1] < XYfh[1]) {XYfh[1] = SD.XYq[i][1];}
         }
        }
       }
       for (i=strlen(Hit1)-1;i>=0;--i) {
        if (Hit1[i]==' ') {
         Hit1[i]='\0';
        }
        else {
         break;
        }
       }
      }
      else {
       XYsh[0] = SD.XYq[0][0]; XYsh[1] = SD.XYq[0][1]; strcpy(Hit2,Annotation);
       if (XYsh[0] <= XYsh[1]) {
        for (i=1;i<HSP;++i) {
         if (SD.XYq[i][0] <= SD.XYq[i][1]) {      // only look at HSPs of orientation matching the orientation of the highest scoring HSP
          if (SD.XYq[i][0] < XYsh[0]) {XYsh[0] = SD.XYq[i][0];}
          if (SD.XYq[i][1] > XYsh[1]) {XYsh[1] = SD.XYq[i][1];}
         }
        }
       }
       else {
        for (i=1;i<HSP;++i) {
         if (SD.XYq[i][0] > SD.XYq[i][1]) {       // only look at HSPs of orientation matching the orientation of the highest scoring HSP
          if (SD.XYq[i][0] > XYsh[0]) {XYsh[0] = SD.XYq[i][0];}
          if (SD.XYq[i][1] < XYsh[1]) {XYsh[1] = SD.XYq[i][1];}
         }
        }
       }
       for (i=strlen(Hit2)-1;i>=0;--i) {
        if (Hit2[i]==' ') {
         Hit2[i]='\0';
        }
        else {
         break;
        }
       }
       if (XYfh[0] <= XYfh[1]) {
        if (XYsh[0] >= XYfh[1]-MaxOverlap  &&  XYsh[1]>=XYfh[1]+MinExtension) {
         if (chimera == 0 ) {
          if (XYsh[0] < XYsh[1]) {
           strcpy(chimeratype,"++");
          }
          else {
           strcpy(chimeratype,"+-");
          }
          *W << "\n  !Potential chimera" << chimeratype << ": Query " << SQn << " matches " << SQf << " (" << Hit1 << ") from " << XYfh[0] << " to " << XYfh[1] << " and " << ID << " (" << Hit2 << ") from " << XYsh[0] << " to " << XYsh[1] << ".\n\n";
          chimera = 1;
         }
        }
       }
       else {
        if (XYsh[0] <= XYfh[1]+MaxOverlap  &&  XYsh[1]<=XYfh[1]-MinExtension) {
         if (chimera == 0 ) {
          if (XYsh[0] < XYsh[1]) {
           strcpy(chimeratype,"-+");
          }
          else {
           strcpy(chimeratype,"--");
          }
          *W << "\n  !Potential chimera" << chimeratype << ": Query " << SQn << " matches " << SQf << " (" << Hit1 << ") from " << XYfh[0] << " to " << XYfh[1] << " and " << ID << " (" << Hit2 << ") from " << XYsh[0] << " to " << XYsh[1] << ".\n\n";
          chimera = 1;
         }
        }
       }
      }                                           // end of C>1 case
     }                                            // OutputChimeras

     cc=cc+1;
    }                                             // end of Rdatafile == 0 case
    (*W).flush();

    if (wG) {                                     //potential full-length CDS
     FullCDs(&wG, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, SD, Fmt, BST, Pstyle, Gc, Startq, Endq);
    }

    if (wI && HSP > 1) {                          //potential alternatively spliced transcript
     AltSplicing(&wI, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, SD, Fmt, BST, Pstyle, Ic);
    }

    if(wR && HSP > 1) {                           //query sequence which may contain repeat segments
     Repeats(&wR, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, SD, Fmt, BST, Pstyle, Rc);
    }

    if (wH) {                                     //sequence similar to the annotated subject sequence
     Homolog(&wH, SQn, DBn, ID, Annotation, SPn, Nbp, FLen, HSP, SD, Fmt, BST, Pstyle, Hc);
    }
   }                                              //end of if(C>Nhits) { } else {
  }                                               //end of while((*rF).peek()!='-') {
 }                                                //end of else { MuSeqBox file input

 if (Fmt == html) {
  *W << "</table>\n";
  if(wI) {
   wI << "</table>\n";
  }
  if(wG) {
   wG << "</table>\n";
  }

  if(wR) {
   wR << "</table>\n";
  }
  if(wH) {
   wH << "</table>\n";
  }
 }

 if(wG && Gc==0) { wG << "\nNo query sequence was found !\n"; }
 if(wH && Hc==0) { wH << "\nNo query sequence was found !\n"; }
 if(wI && Ic==0) { wI << "\nNo query sequence was found !\n"; }
 if(wR && Rc==0) { wR << "\nNo query sequence was found !\n"; }

 if (Fmt != html) {
  if(Ftype==blast) {
   *W << "---------------------\nDatabase information:";
   *W << "\n  Number of letters: " <<Nlet;
   *W << ", Number of sequences: " <<Nseq;
   if(strcmp(Lambda_2,"n/a")==0) {
    *W << "\nBLAST information: ungapped alignment " <<PGM;
    *W << "\n  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
    *W << "\n  " << Matrix << "; " << Penalty <<endl;
   }
   else {
    *W << "\nBLAST information: gapped alignment " <<PGM;
    *W << "\n  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
    *W << "; Gapped: Lambda=" <<Lambda_2 << ", K=" <<K_val_2 << ", H=" <<H_val_2;
    *W << "\n  " << Matrix << "; " << Penalty <<endl;
   }

   if(wG) {
    wG << "---------------------\nDatabase information:";
    wG << "\n  Number of letters: " <<Nlet;
    wG << ", Number of sequences: " <<Nseq;
    if(strcmp(Lambda_2,"n/a")==0) {
     wG << "\nBLAST information: ungapped alignment " <<PGM;
     wG << "\n  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wG << "\n  " << Matrix <<endl;
    }
    else {
     wG << "\nBLAST information: gapped alignment " <<PGM;
     wG << "\n  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wG << "; Gapped: Lambda=" <<Lambda_2 << ", K=" <<K_val_2 << ", H=" <<H_val_2;
     wG << "\n  " << Matrix << "; " << Penalty <<endl;
    }
   }

   if(wH) {
    wH << "---------------------\nDatabase information:";
    wH << "\n  Number of letters: " <<Nlet;
    wH << ", Number of sequences: " <<Nseq;
    if(strcmp(Lambda_2,"n/a")==0) {
     wH << "\nBLAST information: ungapped alignment " <<PGM;
     wH << "\n  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wH << "\n  " << Matrix <<endl;
    }
    else {
     wH << "\nBLAST information: gapped alignment " <<PGM;
     wH << "\n  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wH << "; Gapped: Lambda=" <<Lambda_2 << ", K=" <<K_val_2 << ", H=" <<H_val_2;
     wH << "\n  " << Matrix << "; " << Penalty <<endl;
    }
   }

   if(wI) {
    wI << "---------------------\nDatabase information:";
    wI << "\n  Number of letters: " <<Nlet;
    wI << ", Number of sequences: " <<Nseq;
    if(strcmp(Lambda_2,"n/a")==0) {
     wI << "\nBLAST information: ungapped alignment " <<PGM;
     wI << "\n  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wI << "\n  " << Matrix <<endl;
    }
    else {
     wI << "\n BLAST information: gapped alignment " <<PGM;
     wI << "\n  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wI << "; Gapped: Lambda=" <<Lambda_2 << ", K=" <<K_val_2 << ", H=" <<H_val_2;
     wI << "\n  " << Matrix << "; " << Penalty <<endl;
    }
   }

   if(wR) {
    wR << "---------------------\nDatabase information:";
    wR << "\n  Number of letters: " <<Nlet;
    wR << ", Number of sequences: " <<Nseq;
    if(strcmp(Lambda_2,"n/a")==0) {
     wR << "\nBLAST information: ungapped alignmnet " <<PGM;
     wR << "\n  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wR << "\n  " << Matrix <<endl;
    }
    else {
     wR << "\nBLAST information: gapped alignment " <<PGM;
     wR << "\n  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wR << "; Gapped: Lambda=" <<Lambda_2 << ", K=" <<K_val_2 << ", H=" <<H_val_2;
     wR << "\n  " << Matrix << "; " <<  Penalty <<endl;
    }
   }
  }
  else {
   while((*rF).peek()!=EOF) {
    (*rF).getline(Line,200);
    *W <<Line <<endl;
    if(wG) { wG <<Line <<endl; }
    if(wH) { wH <<Line <<endl; }
    if(wI) { wI <<Line <<endl; }
    if(wR) { wR <<Line <<endl; }
   }
  }
 }                                                //end if  (Fmt != html) {

 else {
  if(Ftype==blast) {
   *W << "---------------------\n<BR>Database information:";
   *W << "\n<BR>  Number of letters: " <<Nlet;
   *W << "  Number of sequences: " <<Nseq;
   if(strcmp(Lambda_2,"n/a")==0) {
    *W << "\n<BR>BLAST information: ungapped alignment " <<PGM;
    *W << "\n<BR>  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
    *W << "<BR>  " << Matrix <<endl;
   }
   else {
    *W << "\n<BR>BLAST information: gapped alignment " <<PGM;
    *W << "\n<BR>  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
    *W << "; Gapped: Lambda=" <<Lambda_2 << ", K=" <<K_val_2 << ", H=" <<H_val_2;
    *W << "<BR>  " << Matrix << "; " << Penalty <<endl;
   }

   if(wG) {
    wG << "---------------------\n<BR>Database information:";
    wG << "\n<BR>  Number of letters: " <<Nlet;
    wG << "  Number of sequences: " <<Nseq;
    if(strcmp(Lambda_2,"n/a")==0) {
     wG << "\n<BR>BLAST information: ungapped alignment " <<PGM;
     wG << "\n<BR>  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wG << "\n  " << Matrix <<endl;
    }
    else {
     wG << "\n<BR>BLAST information: gapped alignment " <<PGM;
     wG << "\n<BR>  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wG << "; Gapped: Lambda=" <<Lambda_2 << ", K=" <<K_val_2 << ", H=" <<H_val_2;
     wG << "<BR>  " << Matrix << "; " << Penalty <<endl;
    }
   }

   if(wH) {
    wH << "---------------------\n<BR>Database information:";
    wH << "\n<BR>  Number of letters: " <<Nlet;
    wH << ", Number of sequences: " <<Nseq;
    if(strcmp(Lambda_2,"n/a")==0) {
     wH << "\n<BR>BLAST information: ungapped alignment " <<PGM;
     wH << "\n<BR>  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wH << "\n  " << Matrix <<endl;
    }
    else {
     wH << "\n<BR>BLAST information: gapped alignment " <<PGM;
     wH << "\n<BR>  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wH << "; Gapped: Lambda=" <<Lambda_2 << ", K=" <<K_val_2 << ", H=" <<H_val_2;
     wH << "<BR>  " << Matrix << "; " << Penalty <<endl;
    }
   }

   if(wI) {
    wI << "---------------------\n<BR>Database information:";
    wI << "\n<BR>  Number of letters: " <<Nlet;
    wI << ", Number of sequences: " <<Nseq;
    if(strcmp(Lambda_2,"n/a")==0) {
     wI << "\n<BR>BLAST information: ungapped alignment " <<PGM;
     wI << "\n<BR>  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wI << "\n  " << Matrix <<endl;
    }
    else {
     wI << "\n<BR> BLAST information: gapped alignment " <<PGM;
     wI << "\n<BR>  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wI << "; Gapped: Lambda=" <<Lambda_2 << ", K=" <<K_val_2 << ", H=" <<H_val_2;
     wI << "<BR>  " << Matrix << "; " << Penalty <<endl;
    }
   }

   if(wR) {
    wR << "---------------------\n<BR>Database information:";
    wR << "\n<BR>  Number of letters: " <<Nlet;
    wR << ", Number of sequences: " <<Nseq;
    if(strcmp(Lambda_2,"n/a")==0) {
     wR << "\n<BR>BLAST information: ungapped alignmnet " <<PGM;
     wR << "\n<BR>  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wR << "\n  " << Matrix <<endl;
    }
    else {
     wR << "\n<BR>BLAST information: gapped alignment " <<PGM;
     wR << "\n<BR>  Lambda=" <<Lambda_1 << ", K=" <<K_val_1 << ", H=" <<H_val_1;
     wR << "; Gapped: Lambda=" <<Lambda_2 << ", K=" <<K_val_2 << ", H=" <<H_val_2;
     wR << "<BR>  " << Matrix << "; " << Penalty <<endl;
    }
   }
  }
  else {
   while((*rF).peek()!=EOF) {
    (*rF).getline(Line,200);
    *W <<Line <<endl;
    if(wG) { wG <<Line <<endl; }
    if(wH) { wH <<Line <<endl; }
    if(wI) { wI <<Line <<endl; }
    if(wR) { wR <<Line <<endl; }
   }
  }
 }                                                //end else  (Ftype!=blast) {

 if (Fmt == html) {
  wF << "</PRE>\n" << "<HR>\n" << "</BODY>\n" << "</HTML>\n";
  if (wG) {
   wG << "</PRE>\n" << "<HR>\n" << "</BODY>\n" << "</HTML>\n";
  }
  if (wH) {
   wH << "</PRE>\n" << "<HR>\n" << "</BODY>\n" << "</HTML>\n";
  }
  if (wI) {
   wI << "</PRE>\n" << "<HR>\n" << "</BODY>\n" << "</HTML>\n";
  }
  if (wR) {
   wR << "</PRE>\n" << "<HR>\n" << "</BODY>\n" << "</HTML>\n";
  }
 }

 Fin.close();
 wF.flush();
 wF.close();
 wG.close();
 wH.close();
 wI.close();
 return 0;
}
