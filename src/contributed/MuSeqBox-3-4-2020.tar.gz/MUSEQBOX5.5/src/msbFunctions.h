//msb.h
#
#ifndef MSB_H
#
#define MSB_H

#include <cctype>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
using namespace std;

#define         DbColWidthMax   16                //text length for Db name
#define         AnnColWidthMax  240               //text length for annotation
#define         MaxHITs         2000              //maximal number of hits
#define         MaxHSPs         10000             //maximal number of HSPs
#define         IDLen           60                //text length for ID name
#define         AOLSize         10                //allowed overlap size

int      Blast_Server=1;                          //1: new Blast server, 0: old Blast server
int      MinGaps, MinReps;
int      StartPosi, EndPosi,Startq, Endq, MAO;    //MAO: Maximal Allowed Overlap
int      Nhits = MaxHITs;
int      Nhsps = MaxHSPs;
int      IndelType;                               //1: insertion; 2: deletion
int      RepsSrc;                                 //1: query; 2: subject
int      bgci=5;
int      bgcg=5;
int      bgcr=5;
int      bgch=5;
int      QidSize=12;                              //print length for queryID
int      DbColWidthPrt=5;                         //print length for DB column
int      AnnColWidthPrt=36;                       //print length for Annotation column
int      SrcSize=24;                              //print length for Source column
float    Hpct, HCpct;
float    SCpct, QCpct;

enum Boolean { yes, no };
enum Tdbase { gi, gb, emb, pir, dbj, sp, ref, pdb, prf, bbs, gnl, pat, lcl, tpe, oth };
enum BLAST { blastx, blastn, blastp, tblastn, tblastx, rpsblast, rpstblastn };
enum FileType { blast, parsed };
enum OutFmt { text, html };

Boolean  GetSPn = no;

struct DTtype
{
 long   XYs[MaxHSPs][2];                          //subject HSP coordinates
 long   XYq[MaxHSPs][2];                          //query HSP coordinates
 char   E[MaxHSPs][8];                            //expectation values
 float  Score[MaxHSPs];                           //bit score for sequence alignment
 float  SCov[MaxHSPs];                            //HSP coverage over the subject sequence
 float  QCov[MaxHSPs];                            //HSP coverage over the query sequence
 float  Iden[MaxHSPs];                            //percent identity
 float  Simi[MaxHSPs];                            //percent similarity
 int    Gaps[MaxHSPs];                            //number of gaps
 char   Frame[MaxHSPs][6];                        //strand status or reading frame
};

void Syntax()
{
 cout << "\nUsage:\n";
 cout << "\n MuSeqBox     [-]  [-i infname]  [-g] [-n nhits]  [-s nhsps]  [-q]  [-z]  [-c crtfile]";
 cout << "\n     [-o outfname]  [-t|h]  [-l idsize]  [-d dbsize]  [-L ansize]  [-k srcsize]  [-p pstyle]";
 cout << "\n     [-A pid mao scv outfan]  [-F d5p d3p scv qcv outffl]";
 cout << "\n     [-I indel type outfas] [-R rps src outfrp]\n";
 cout << "\n -          : read input from standard input";
 cout << "\n -i infname : read input from file 'infname'";
 cout << "\n -g         : get species name for subject sequences";
 cout << "\n -n nhits   : select the first 'nhits' from the BLAST hit list for each query";
 cout << "\n               [default: select all hits (up to " << MaxHITs << ")]";
 cout << "\n -s nhsps   : select the best 'nhsps' HSPs from each hit";
 cout << "\n               [default: " << MaxHSPs << " (=maximum allowed)]";
 cout << "\n -q         : print the query IDs of queries with no BLAST hits";
 cout << "\n -z         : Allow sequences in non-standard format";
 cout << "\n -c crtfile : read the criteria for hit selection specified by the user in";
 cout << "\n               the file 'crtfile'";
 cout << "\n -o outfname: write output to file 'outfname'. An extension name '.html' will";
 cout << "\n               be added if option -h is specified.";
 cout << "\n               [default: standard output]";
 cout << "\n -t|h       : produce output in text [-t default] or HTML format [-h]";
 cout << "\n -l idsize  : Set column width for QueryID and SubjectID (default idsize=12; maximum=" << IDLen << ")";
 cout << "\n -d dbsize  : Set column width for DB (default dbsize=5; maximum=" << DbColWidthMax << ")";
 cout << "\n -L ansize  : Set column width for Annotation (default ansize=36; maximum=" << AnnColWidthMax << ")";
 cout << "\n -k srsize  : Set column width for Source (default srsize=24; maximum=" << IDLen << ")";
 cout << "\n -p pstyle  : 1 (columns with text description only); 2 (columns with numeric";
 cout << "\n               values only); 3 (condensed form) and 4 (default)";
 cout << "\n -A pid mao scv outfan: Annotation.";
 cout << "\n              Select hits according to the criteria";
 cout << "\n               (1) at least 'pid'% identity in each selected HSP,";
 cout << "\n               (2) selected HSPs overlap by at most 'mao' positions,";
 cout << "\n               (3) at least 'scv'% cumulative coverage of the matched subject.";
 cout << "\n              Write the output to file 'outfan'.";
 cout << "\n -F v5s v3s v5q v3q scv qcv outffl: Full-length coding sequences.";
 cout << "\n              Select hits which likely correspond to full-length, 5'- or 3'-";
 cout << "\n              coding sequences according to the criteria";
 cout << "\n               (1) 'v5s', max variance in subject at starting position of 5' end,";
 cout << "\n               (2) 'v3s', max variance in subject at ending position of 3' end,";
 cout << "\n               (3) 'v5q', max variance in query at starting position of 5' end,";
 cout << "\n               (4) 'v3q', max variance in query at ending position of 3' end,";
 cout << "\n               (5) 'scv', minimal cumulative coverage of the matched subject,";
 cout << "\n               (6) 'qcv', minimal cumulative coverage of the query.";
 cout << "\n              Write the output to file 'outffl'.";
 cout << "\n -I indel type outfas: Retained introns, alternative splicing.";
 cout << "\n              Select hits which indicate potential alternatively spliced";
 cout << "\n              transcripts [of minimal 'type' size 'indel'; 'type', 1 for";
 cout << "\n              insertion, and 2 for deletion].";
 cout << "\n              Write the output to file 'outfas'.";
 cout << "\n -M mov mex: Indicate potential chimeric queries.";
 cout << "\n              Potential chimeric queries have two hits to different subject";
 cout << "\n              sequences, with the hits overlapping at most 'mov' positions and";
 cout << "\n              the endpoint of the second hit extending at least 'mex' positions";
 cout << "\n              beyond the endpoint of the first hit.";
 cout << "\n -R rps src outfrp: Repeats.";
 cout << "\n              Select hits which indicate repetitive structures in either query";
 cout << "\n              or subject. 'rps', minimal potential repeat size;";
 cout << "\n              'src', 1 for query repeat structures, and 2 for subject repeat";
 cout << "\n              structures. Write the output to file 'outfrp'.\n\n";
}


void Warning()
{
 cout << "\nError: detected either invalid or missing command-line parameters !\n";
 cout << "\nUsage:    MuSeqBox  [-]  [-i infname]  [-g]  [-n nhits]  [-s nhsps]  [-q]  [-z]";
 cout << "\n   [-c crtfile]  [-o outfname]  [-t|h]  [-l idsize]  [-L ansize]  [-k srsize]  [-p pstyle]";
 cout << "\n   [-A pid mao scv outfan]  [-F v5s v3s v5q v3q scv qcv outffl]";
 cout << "\n   [-I indel type outfas]  [-M mov mex]  [-R rps src outfrp]\n\n";
}


Tdbase DBaseF(const char *DT)
{
 Tdbase Dbase;
 switch (*DT) {
  case 'g':
   switch (*(DT + 1)) {
    case 'i': Dbase = gi;  break;
    case 'b': Dbase = gb;  break;
    case 'n': Dbase = gnl; break;
   }
   break;
  case 'p':
   switch (*(DT + 1)) {
    case 'i': Dbase = pir; break;
    case 'd': Dbase = pdb; break;
    case 'r': Dbase = prf; break;
    case 'a': Dbase = pat; break;
   }
   break;
  case 'e': Dbase = emb; break;
  case 'd': Dbase = dbj; break;
  case 'b': Dbase = bbs; break;
  case 'r': Dbase = ref; break;
  case 's': Dbase = sp;  break;
  case 'l': Dbase = lcl; break;
  case 't': Dbase = tpe; break;
  default:  Dbase = oth; break;
 }                                                //end of switch(DB[0]) {
 return Dbase;
}                                                 //determine type of database


char *IDnumber(istream * F, char *ID)
{
 char *id = ID;
 int i = 0;
 while ((*F).peek() != '|' && (*F).peek() != ' ' && i < IDLen && (*F).peek() != EOF) {
  (*F).get(*(id + i));
  i++;
 }
 *(id + i) = '\0';
 return id;
}                                                 //get the GenBank identification number


void SortDT(DTtype &DT, int HSP, int _012)
{
 //sorting using coordinates, 0:Qxy, 1:Sxy, 2:eval and score

 long int    XYq[2], XYs[2], Gap;
 int         i, YES;
 char        E[8], Frm[6];
 float       SCov, QCov, Iden, Simi, Score;

 for (i = 0; i < HSP - 1; i++) {
  for (int j = i + 1; j < HSP; j++) {

   switch(_012) {
    case 0:                                       // use of query coordinates
     if (DT.XYq[i][0] > DT.XYq[j][0]) { YES=1; }
     else { YES=0; }
     break;
    case 1:                                       // use of subject coordinates
     if (DT.XYs[i][0] > DT.XYs[j][0]) { YES=1; }
     else { YES=0; }
     break;
    case 2:                                       // use of expected value and score
     if (atof(DT.E[i]) > atof(DT.E[j])) { YES=1; }
     else {
      if(atof(DT.E[i])==atof(DT.E[j]) && DT.Score[i] < DT.Score[j] ) {
       YES=1;
      }
      else {
       YES=0;
      }
     }
     break;
   }

   if(YES==1) {
    XYq[0] = DT.XYq[i][0];
    XYq[1] = DT.XYq[i][1];
    XYs[0] = DT.XYs[i][0];
    XYs[1] = DT.XYs[i][1];
    strcpy(E, DT.E[i]);
    strcpy(Frm, DT.Frame[i]);
    Score = DT.Score[i];
    SCov = DT.SCov[i];
    Iden = DT.Iden[i];
    Simi = DT.Simi[i];
    QCov = DT.QCov[i];
    Gap = DT.Gaps[i];

    DT.XYq[i][0] = DT.XYq[j][0];
    DT.XYq[i][1] = DT.XYq[j][1];
    DT.XYs[i][0] = DT.XYs[j][0];
    DT.XYs[i][1] = DT.XYs[j][1];
    strcpy(DT.E[i], DT.E[j]);
    strcpy(DT.Frame[i], DT.Frame[j]);
    DT.Score[i] = DT.Score[j];
    DT.SCov[i] = DT.SCov[j];
    DT.Iden[i] = DT.Iden[j];
    DT.Simi[i] = DT.Simi[j];
    DT.QCov[i] = DT.QCov[j];
    DT.Gaps[i] = DT.Gaps[j];

    DT.XYq[j][0] = XYq[0];
    DT.XYq[j][1] = XYq[1];
    DT.XYs[j][0] = XYs[0];
    DT.XYs[j][1] = XYs[1];
    strcpy(DT.E[j], E);
    strcpy(DT.Frame[j], Frm);
    DT.Score[j] = Score;
    DT.SCov[j] = SCov;
    DT.Iden[j] = Iden;
    DT.Simi[j] = Simi;
    DT.QCov[j] = QCov;
    DT.Gaps[j] = Gap;
   }
  }
 }
}


void Headings(ostream * F, BLAST BST, int Pstyle)
{
 int i;
 switch(Pstyle) {
  case 1:
   *F << "QueryID";
   for(i=0; i< QidSize-6; i++) *F << " ";
   *F << "SubjectID";
   for(i=0; i< QidSize-7; i++) *F << " ";
   *F << "Db";
   for(i=0; i< DbColWidthPrt-1; i++) *F << " ";
   *F << "Annotation";
   if(GetSPn == yes) {
    for(i=0; i<AnnColWidthPrt-10; i++) *F << " ";
    *F << " Source\n";
    for(i=0; i<2*QidSize+DbColWidthPrt+AnnColWidthPrt+SrcSize+5; i++) { *F << "-"; }
   }
   else {
    *F << endl;
    for(i=0; i<2*QidSize+DbColWidthPrt+AnnColWidthPrt+4; i++) { *F << "-"; }
   }
   *F << endl;
   break;
  case 2:
   *F << "QueryID";
   for(i=0; i< QidSize-6; i++) *F << " ";
   *F << "SubjectID";
   for(i=0; i< QidSize-8; i++) *F << " ";
   *F << " QLen " << " HSP   " << "  HLen ";
   *F << " CovQ " << "   Qx " << "   Qy ";

   if(BST==blastn) { *F << "      Sx " << "      Sy " << "    SLen"; }
   else { *F << "   Sx " << "   Sy " << " SLen"; }
   *F << "  CovS" << "   Pid";
   if(BST==blastn) { *F << " NGap" << "  Sts"; }
   else {
    if(BST==blastp || BST==rpsblast) { *F << "   Psi" << " NGap"; }
    else { *F << "   Psi" << " NGap" << " Frame"; }
   }
   *F << "  Score" << "  Eval\n";
   for(i=0; i<2*QidSize+93; i++) { *F << "-"; }
   if(! (BST==blastp || BST==rpsblast)) *F << "------";
   *F << endl;
   break;
  case 3:
   *F << "QueryID";
   for(i=0; i< QidSize-6; i++) *F << " ";
   *F << "SubjectID";
   for(i=0; i< QidSize-7; i++) *F << " ";

   *F << " HSP   " << "  HLen " << " CovQ ";
   *F << " CovS " << "  Pid" << " NGap";
   if(BST==blastn) { *F << "  Sts"; }
   else {
    if(BST != blastp && BST != rpsblast) { *F << " Frame"; }
   }
   *F << " Eval" << "    Annotation\n";
   for(i=0; i<2*QidSize+AnnColWidthPrt+46; i++) { *F << "-"; }
   if(! (BST==blastp || BST==rpsblast)) *F << "------";
   *F << endl;
   break;
  case 4:
   *F << "QueryID";
   for(i=0; i< QidSize-6; i++) *F << " ";
   *F << "SubjectID";
   for(i=0; i< QidSize-8; i++) *F << " ";

   *F<< " QLen " << " HSP   " << "  HLen ";
   *F << " CovQ " << "   Qx " << "   Qy ";
   if(BST!=blastn) { *F << "   Sx " << "   Sy " << " SLen"; }
   else { *F << "      Sx " << "      Sy " << "    SLen"; }

   *F << "  CovS" << "   Pid";
   if(BST==blastn) { *F << " NGap" << "  Sts"; }
   else {
    if(BST==blastp || BST==rpsblast) { *F << "   Psi" << " NGap"; }
    else {*F << "   Psi" << " NGap" << " Frame"; }
   }

   *F << "    Score" << "  Eval    Db";
   for(i=0; i< DbColWidthPrt-1; i++) *F << " ";
   *F << "Annotation";
   if(GetSPn == yes) {
    for(i=0; i<AnnColWidthPrt-10; i++) { *F << " "; }
    *F << " Source\n";
    for(i=0; i<2*QidSize+DbColWidthPrt+AnnColWidthPrt+SrcSize+101; i++) { *F << "-"; }
   }
   else {
    *F << "\n";
    for(i=0; i<2*QidSize+DbColWidthPrt+AnnColWidthPrt+100; i++) { *F << "-"; }
   }
   if(! (BST==blastp || BST==rpsblast)) *F << "------";
   *F << endl;
   break;
 }
}


void print(ostream *F, char *SQ, char *DB, char *ID, char *Annotation, char *SP, int Nbp,
int SLen, int HSP, int mHSP, DTtype D, OutFmt Fmt, BLAST BST, int Pstyle, int mybgcolor)
{
 int  i, j;
 char URL[]="<A HREF=\"http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Search&db=";
 char PDB[]="&doptcmdl=GenPept\" target=\"_blank\">";
 char NDB[]="&doptcmdl=GenBank\" target=\"_blank\">";
 char NB1[]="<A HREF=\"http://www.ncbi.nlm.nih.gov/blast/Blast.cgi?ALIGNMENTS=50";
 char NB2[]="&ALIGNMENT_VIEW=Pairwise&AUTO_FORMAT=on&CLIENT=web&DATABASE=nr&EXPECT=10";
 char NB3[]="&DESCRIPTIONS=100&ENTREZ_QUERY=(none)&FILTER=L&FORMAT_OBJECT=Alignment&";
 char NB4[]="FORMAT_TYPE=HTML&HITLIST_SIZE=100&NCBI_GI=on&SERVICE=plain";
 char NB5[]="&SHOW_OVERVIEW=on&END_OF_HTTPGET=Yes\" target=\"_blank\">";
 char PM1[]="<A HREF=\"http://www.ncbi.nlm.nih.gov/blast/blast.cgi?ADV_LAB=&PROGRAM";
 char PM2[]="&DATALIB=nr&FILTER=L&INPUT_TYPE=Accession+or+GI&SEQUENCE=";
 char PM3[]="&DOUBLE_WINDOW=IS_SET&OVERVIEW=on&ALIGNMENT_VIEW";
 char PM4[]="=0&DESCRIPTIONS=100&ALIGNMENTS=50&PATH=\" target=\"_blank\">";

 if (SQ[0]=='P' && SQ[1]=='U' && SQ[2]=='T' && SQ[3]=='-') {
  strcpy(URL,"<A HREF=\"http://www.plantgdb.org/search/display/data.php?Seq_ID=");
  strcpy(PDB,"\" target=\"_blank\">");
 }

 //DEBUG *F << "\nIn PRINT" << endl;
 switch(Pstyle) {
  case 1:
   *F <<setiosflags(ios::left);
   if(Fmt==html) {
    if(mybgcolor==2) {
     *F << "<tr><td bgcolor=\"#ffffff\"><pre>";
    }
    else {
     *F << "<tr><td bgcolor=\"#bfbfbf\"><pre>";
    }

    *F <<URL;
    if (SQ[0]=='P' && SQ[1]=='U' && SQ[2]=='T' && SQ[3]=='-') {
     *F << SQ << PDB << SQ << "</A>";
    }
    else {
     if(BST==blastp || BST==rpsblast  || BST==tblastn || BST==rpstblastn) {
      *F << "Protein&term=" <<SQ <<PDB <<SQ << "</A>";
     }
     else {
      *F << "Nucleotide&term=" <<SQ <<NDB <<SQ << "</A>";
     }
    }
   }
   else {
    *F <<SQ;
   }
   if(strlen(SQ)<QidSize) {
    for(i=0; i<(QidSize+1-strlen(SQ)); i++) { *F << " "; }
   }
   else { *F << " "; }
   if(Fmt==html) {
    if(BST==blastx || BST==blastp || BST==rpsblast) {
     if(strcmp(DB,"UniProt") == 0) {
      *F << "<A HREF=\"http://www.pir.uniprot.org/cgi-bin/upEntry?id=" << ID << "\" target=\"_blank\">" << ID << "</A>" ;
     }
     else {
      *F <<URL;
      *F << "Protein&term=" <<ID <<PDB <<ID << "</A>";
     }
    }
    else {
     *F <<URL;
     *F << "Nucleotide&term=" <<ID <<NDB <<ID << "</A>";
    }
   }
   else {
    *F <<ID;
   }
   if(strlen(ID)<QidSize) {
    for(i=0; i<=QidSize-strlen(ID); i++) { *F << " "; }
   }
   else { *F << " "; }
   *F << " " <<setw(DbColWidthPrt)<<DB << " " <<setw(AnnColWidthPrt)<<Annotation;
   if(GetSPn == yes) {
    *F << " " << SP;
   }
   *F << endl;
   *F <<resetiosflags(ios::left);

   if(Fmt==html) {
    *F << "</pre></td></tr>";
   }
   break;

  case 2:
   for(i=0; i<HSP && i<mHSP; i++) {

    if(Fmt==html) {
     if(mybgcolor==2) {
      *F << "<tr><td bgcolor=\"#ffffff\"><pre>";
     }
     else {
      *F << "<tr><td bgcolor=\"#bfbfbf\"><pre>";
     }
    }
    *F <<setiosflags(ios::left);
    if(Fmt==html) {
     *F <<URL;
     if (SQ[0]=='P' && SQ[1]=='U' && SQ[2]=='T' && SQ[3]=='-') {
      *F << SQ << PDB << SQ << "</A>";
     }
     else {
      if(BST==blastp || BST==rpsblast  || BST==tblastn || BST==rpstblastn) {
       *F << "Protein&term=" <<SQ <<PDB <<SQ << "</A>";
      }
      else {
       *F << "Nucleotide&term=" <<SQ <<NDB <<SQ << "</A>";
      }
     }
    }
    else { *F <<SQ; }
    if(strlen(SQ)<QidSize) {
     for(j=0; j<(QidSize+1-strlen(SQ)); j++) { *F << " "; }
    }
    else { *F << " "; }
    if(Fmt==html) {
     if(BST==blastx || BST==blastp || BST==rpsblast) {
      if(strcmp(DB,"UniProt") == 0) {
       *F << "<A HREF=\"http://www.pir.uniprot.org/cgi-bin/upEntry?id=" << ID << "\" target=\"_blank\">" << ID << "</A>" ;
      }
      else {
       *F <<URL;
       *F << "Protein&term=" <<ID <<PDB <<ID << "</A>";
      }
     }
     else {
      *F << "Nucleotide&term=" <<ID <<NDB <<ID << "</A>";
     }
    }
    else { *F <<ID; }
    if(strlen(ID)<QidSize) {
     for(j=0; j<=QidSize-strlen(ID); j++) { *F << " "; }
    }
    else { *F << " "; }
    *F <<resetiosflags(ios::left);
    *F <<setw(5) << Nbp << " " << setw(3) << (i + 1) << "/";
    if (HSP >= 100) {
     *F << HSP << " ";
    }
    else if (HSP >= 10) {
     *F << HSP << "  ";
    }
    else {
     *F << HSP << "   ";
    }

    *F <<setw(5) <<(labs(D.XYq[i][0] - D.XYq[i][1]) + 1) << " ";
    *F <<setiosflags(ios::fixed) <<setiosflags(ios::showpoint) <<setprecision(1);
    *F <<setw(5) <<D.QCov[i] << " "<<setprecision(0);

    *F <<setw(5) <<D.XYq[i][0] << " " <<setw(5) <<D.XYq[i][1] << " ";
    if(BST==blastn) {
     *F <<setw(8) <<D.XYs[i][0] << " " <<setw(8) <<D.XYs[i][1] << " "
      <<setw(8) <<SLen;
    }
    else {
     *F <<setw(5) <<D.XYs[i][0] << " " <<setw(5) <<D.XYs[i][1] << " "
      <<setw(5) <<SLen;
    }
    *F << setprecision(1) <<setw(6) <<D.SCov[i] <<setw(6) <<D.Iden[i];

    if(BST==blastn) {
     *F <<setw(5) <<D.Gaps[i] << " " <<setw(4) <<D.Frame[i];
    }
    else {
     if(BST==blastp || BST==rpsblast) { *F <<setw(6) <<D.Simi[i] <<setw(5) <<D.Gaps[i]; }
     else {
      *F <<setw(6) <<D.Simi[i] <<setw(5) <<D.Gaps[i] <<setw(6) <<D.Frame[i];
     }
    }
    *F << "  " <<setw(5) <<D.Score[i] <<setiosflags(ios::left) << "  ";

    if(Fmt==html) {
     if(Blast_Server==1) {
      *F <<NB1 <<NB2 <<NB3 <<NB4;
      switch (BST) {
       case blastn:
        *F << "&PROGRAM=blastn&PAGE=Nucleotides&SET_DEFAULTS.x=34&"
         << "SET_DEFAULTS.y=8";
        break;
       case blastx:
        *F << "&PROGRAM=blastx&GENETIC_CODE=1&SET_DEFAULTS.x=34&SET_DEFAULTS.y=8"
         << "&PAGE=Translations&UNGAPPED_ALIGNMENT=no";
        break;
       case blastp: case rpsblast:
        *F << "&PROGRAM=blastp&CDD_SEARCH=on&COMPOSITION_BASED_STATISTICS=on"
         << "&I_THRESH=0.001&MATRIX_NAME=BLOSUN62&PAGE=Proteins"
         << "&SET_DEFAULTS.x=41&SET_DEFAULTS.y=5";
        break;
       case tblastn: case rpstblastn:
        *F << "&PROGRAM=tblastn&GENETIC_CODE=0&PAGE=Translations&SET_DEFAULTS.x=23"
         << "&SET_DEFAULTS.y=10&UNGAPPED_ALIGNMENT=no";
        break;
       case tblastx:
        *F << "&PROGRAM=tblastx&GENETIC_CODE=1&PAGE=Translations&SET_DEFAULTS.x=21"
         << "&SET_DEFAULTS.y=9&UNGAPPED_ALIGNMENT=yes";
        break;
      }
      *F << "&QUERY=" <<SQ <<NB5 <<D.E[i] << "</A>";
     }
     else {
      *F <<PM1;
      switch (BST) {
       case blastn:  *F << "=blastn"; break;
       case blastx:  *F << "=blastx"; break;
       case blastp: case rpsblast:  *F << "=blastp"; break;
       case tblastn: case rpstblastn: *F << "=tblastn"; break;
       case tblastx: *F << "=tblastx"; break;
      }
      *F <<PM2 <<SQ <<PM3 <<PM4 <<D.E[i] << "</A>";
     }
    }
    else { *F <<D.E[i]; }
    *F <<resetiosflags(ios::left) <<endl;
   }
   if(Fmt==html) {
    *F << "</pre></td></tr>";
   }
   break;

  case 3:
   for(i=0; i<HSP && i<mHSP; i++) {

    if(Fmt==html) {
     if(mybgcolor==2) {
      *F << "<tr><td bgcolor=\"#ffffff\"><pre>";
     }
     else {
      *F << "<tr><td bgcolor=\"#bfbfbf\"><pre>";
     }
    }

    *F <<setiosflags(ios::left);
    if(Fmt==html) {
     *F <<URL;
     if (SQ[0]=='P' && SQ[1]=='U' && SQ[2]=='T' && SQ[3]=='-') {
      *F << SQ << PDB << SQ << "</A>";
     }
     else {
      if(BST==blastp || BST==rpsblast  || BST==tblastn || BST==rpstblastn) {
       *F << "Protein&term=" <<SQ <<PDB <<SQ << "</A>";
      }
      else {
       *F << "Nucleotide&term=" <<SQ <<NDB <<SQ << "</A>";
      }
     }
    }
    else { *F <<SQ; }
    if(strlen(SQ)<QidSize) {
     for(j=0; j<(QidSize+1-strlen(SQ)); j++) { *F << " "; }
    }
    else { *F << " "; }
    if(Fmt==html) {
     if(BST==blastx || BST==blastp || BST==rpsblast) {
      if(strcmp(DB,"UniProt") == 0) {
       *F << "<A HREF=\"http://www.pir.uniprot.org/cgi-bin/upEntry?id=" << ID << "\" target=\"_blank\">" << ID << "</A>" ;
      }
      else {
       *F <<URL;
       *F << "Protein&term=" <<ID <<PDB <<ID << "</A>";
      }
     }
     else {
      *F <<URL;
      *F << "Nucleotide&term=" <<ID <<NDB <<ID << "</A>";
     }
    }
    else { *F <<ID; }
    if(strlen(ID)<QidSize) {
     for(j=0; j<=QidSize-strlen(ID); j++) { *F << " "; }
    }
    else { *F << " "; }
    *F << " " <<resetiosflags(ios::left);
    *F <<setw(3) << (i + 1) << "/";
    if (HSP >= 100) {
     *F << HSP << " ";
    }
    else if (HSP >= 10) {
     *F << HSP << "  ";
    }
    else {
     *F << HSP << "   ";
    }

    *F <<setw(5) <<(labs(D.XYq[i][0] - D.XYq[i][1]) + 1) << " ";
    *F <<setiosflags(ios::fixed) <<setiosflags(ios::showpoint) <<setprecision(1);
    *F <<setw(5) <<D.QCov[i] << setw(6) <<D.SCov[i] <<setw(6) <<D.Iden[i]
     <<setw(5) <<D.Gaps[i] << " ";
    if(BST==blastn) {
     *F <<setw(4) <<D.Frame[i] << " " <<setiosflags(ios::left);
    }
    else {
     if(BST != blastp && BST != rpsblast) { *F <<setw(5) <<D.Frame[i] << " " <<setiosflags(ios::left); }
    }

    if(Fmt==html) {
     if(Blast_Server==1) {
      *F <<NB1 <<NB2 <<NB3 <<NB4;
      switch (BST) {
       case blastn:
        *F << "&PROGRAM=blastn&PAGE=Nucleotides&SET_DEFAULTS.x=34&"
         << "SET_DEFAULTS.y=8";
        break;
       case blastx:
        *F << "&PROGRAM=blastx&GENETIC_CODE=1&SET_DEFAULTS.x=34&SET_DEFAULTS.y=8"
         << "&PAGE=Translations&UNGAPPED_ALIGNMENT=no";
        break;
       case blastp: case rpsblast:
        *F << "&PROGRAM=blastp&CDD_SEARCH=on&COMPOSITION_BASED_STATISTICS=on"
         << "&I_THRESH=0.001&MATRIX_NAME=BLOSUN62&PAGE=Proteins"
         << "&SET_DEFAULTS.x=41&SET_DEFAULTS.y=5";
        break;
       case tblastn: case rpstblastn:
        *F << "&PROGRAM=tblastn&GENETIC_CODE=0&PAGE=Translations&SET_DEFAULTS.x=23"
         << "&SET_DEFAULTS.y=10&UNGAPPED_ALIGNMENT=no";
        break;
       case tblastx:
        *F << "&PROGRAM=tblastx&GENETIC_CODE=1&PAGE=Translations&SET_DEFAULTS.x=21"
         << "&SET_DEFAULTS.y=9&UNGAPPED_ALIGNMENT=yes";
        break;
      }
      *F << "&QUERY=" <<SQ <<NB5 <<D.E[i] << "</A>";
     }
     else {
      *F <<PM1;
      switch (BST) {
       case blastn:  *F << "=blastn"; break;
       case blastx:  *F << "=blastx"; break;
       case blastp: case rpsblast:  *F << "=blastp"; break;
       case tblastn: case rpstblastn: *F << "=tblastn"; break;
       case tblastx: *F << "=tblastx"; break;
      }
      *F <<PM2 <<SQ <<PM3 <<PM4 <<D.E[i] << "</A>";
     }
    }
    else { *F <<D.E[i]; }
    if(strlen(D.E[i])<7) {
     for(j=0; j<8-strlen(D.E[i]); j++) { *F << " "; }
    }
    *F <<setw(AnnColWidthPrt) <<Annotation <<resetiosflags(ios::left) << "\n";
   }

   if(Fmt==html) {
    *F << "</pre></td></tr>";
   }

   break;

  case 4:
   for(i=0; i<HSP && i<mHSP; i++) {

    if(Fmt==html) {
     if(mybgcolor==2) {
      *F << "<tr><td bgcolor=\"#ffffff\"><pre>";
     }
     else {
      *F << "<tr><td bgcolor=\"#bfbfbf\"><pre>";
     }
    }

    *F <<setiosflags(ios::left);
    if(Fmt==html) {
     *F <<URL;
     if (SQ[0]=='P' && SQ[1]=='U' && SQ[2]=='T' && SQ[3]=='-') {
      *F << SQ << PDB << SQ << "</A>";
     }
     else {
      if(BST==blastp || BST==rpsblast  || BST==tblastn || BST==rpstblastn) {
       *F << "Protein&term=" <<SQ <<PDB <<SQ << "</A>";
      }
      else {
       *F << "Nucleotide&term=" <<SQ <<NDB <<SQ << "</A>";
      }
     }
    }
    else { *F <<SQ; }
    if(strlen(SQ)<QidSize) {
     for(j=0; j<(QidSize+1-strlen(SQ)); j++) { *F << " "; }
    }
    else { *F << " "; }
    if(Fmt==html) {
     if(BST==blastx || BST==blastp || BST==rpsblast) {
      if(strcmp(DB,"UniProt") == 0) {
       *F << "<A HREF=\"http://www.pir.uniprot.org/cgi-bin/upEntry?id=" << ID << "\" target=\"_blank\">" << ID << "</A>" ;
      }
      else {
       *F <<URL;
       *F << "Protein&term=" <<ID <<PDB <<ID << "</A>";
      }
     }
     else {
      *F <<URL;
      *F << "Nucleotide&term=" <<ID <<NDB <<ID << "</A>";
     }
    }
    else { *F <<ID; }
    if(strlen(ID)<QidSize) {
     for(j=0; j<=QidSize-strlen(ID); j++) { *F << " "; }
    }
    else { *F << " "; }
    *F <<resetiosflags(ios::left);
    *F <<setw(5) << Nbp << " " << setw(3) << (i + 1) << "/";
    if (HSP >= 100) {
     *F << HSP << " ";
    }
    else if (HSP >= 10) {
     *F << HSP << "  ";
    }
    else {
     *F << HSP << "   ";
    }

    *F <<setw(5) <<(labs(D.XYq[i][0] - D.XYq[i][1]) + 1) << " ";
    *F <<setiosflags(ios::fixed) <<setiosflags(ios::showpoint) <<setprecision(1);
    *F <<setw(5) <<D.QCov[i] << " "<<setprecision(0);

    *F <<setw(5) <<D.XYq[i][0] << " " <<setw(5) <<D.XYq[i][1] << " ";
    if(BST==blastn) {
     *F <<setw(8) <<D.XYs[i][0] << " " <<setw(8) <<D.XYs[i][1] << " "
      <<setw(8) <<SLen;
    }
    else {
     *F <<setw(5) <<D.XYs[i][0] << " " <<setw(5) <<D.XYs[i][1] << " "
      <<setw(5) <<SLen;
    }
    *F << setprecision(1) <<setw(6) <<D.SCov[i] <<setw(6) <<D.Iden[i];

    if(BST==blastn) {
     *F <<setw(5) <<D.Gaps[i] << " " <<setw(4) <<D.Frame[i];
    }
    else {
     if(BST==blastp || BST==rpsblast) { *F <<setw(6) <<D.Simi[i] <<setw(5) <<D.Gaps[i]; }
     else {
      *F <<setw(6) <<D.Simi[i] <<setw(5) <<D.Gaps[i] <<setw(6) <<D.Frame[i];
     }
    }
    *F <<setw(9) <<D.Score[i] <<setiosflags(ios::left) << "  ";

    if(Fmt==html) {
     if(Blast_Server==1) {
      *F <<NB1 <<NB2 <<NB3 <<NB4;
      switch (BST) {
       case blastn:
        *F << "&PROGRAM=blastn&PAGE=Nucleotides&SET_DEFAULTS.x=34&"
         << "SET_DEFAULTS.y=8";
        break;
       case blastx:
        *F << "&PROGRAM=blastx&GENETIC_CODE=1&SET_DEFAULTS.x=34&SET_DEFAULTS.y=8"
         << "&PAGE=Translations&UNGAPPED_ALIGNMENT=no";
        break;
       case blastp: case rpsblast:
        *F << "&PROGRAM=blastp&CDD_SEARCH=on&COMPOSITION_BASED_STATISTICS=on"
         << "&I_THRESH=0.001&MATRIX_NAME=BLOSUN62&PAGE=Proteins"
         << "&SET_DEFAULTS.x=41&SET_DEFAULTS.y=5";
        break;
       case tblastn: case rpstblastn:
        *F << "&PROGRAM=tblastn&GENETIC_CODE=0&PAGE=Translations&SET_DEFAULTS.x=23"
         << "&SET_DEFAULTS.y=10&UNGAPPED_ALIGNMENT=no";
        break;
       case tblastx:
        *F << "&PROGRAM=tblastx&GENETIC_CODE=1&PAGE=Translations&SET_DEFAULTS.x=21"
         << "&SET_DEFAULTS.y=9&UNGAPPED_ALIGNMENT=yes";
        break;
      }
      *F << "&QUERY=" <<SQ <<NB5 <<D.E[i] << "</A>";
     }
     else {
      *F <<PM1;
      switch (BST) {
       case blastn:  *F << "=blastn"; break;
       case blastx:  *F << "=blastx"; break;
       case blastp: case rpsblast:  *F << "=blastp"; break;
       case tblastn: case rpstblastn: *F << "=tblastn"; break;
       case tblastx: *F << "=tblastx"; break;
      }
      *F <<PM2 <<SQ <<PM3 <<PM4 <<D.E[i] << "</A>";
     }
    }
    else { *F <<D.E[i]; }
    if(strlen(D.E[i])<7) {
     for(j=0; j<7-strlen(D.E[i]); j++) { *F << " "; }
    }
    *F << " " <<setw(DbColWidthPrt)<<DB << " " <<setw(AnnColWidthPrt)<<Annotation;
    if(GetSPn == yes) {
     *F << " " << SP;
    }
    *F << endl;
    *F <<resetiosflags(ios::left);

    if(Fmt==html) {
     *F << "</pre></td></tr>";
    }
   }
   break;
 }
}


void AltSplicing(ostream *F, char *SQ, char *DB, char *ID, char *Annotation, char *SP,
int Nbp, int SLen, int HSP, DTtype SD, OutFmt Fmt, BLAST BST,
int Pstyle, int &Ic)
{
 long int SIZE, HSP2 = 0, Inx = 0;
 long int i, j, Findel;
 DTtype  SDS;

 SortDT(SD, HSP, 1);                              //sort the data based on the subject coordinates
 switch(IndelType) {
  case 1:
   for(i=0; i<HSP-1; i++) {
    for(j=i+1; j<HSP; j++) {
     if((labs(SD.XYs[i][0]-SD.XYs[j][0])<=10 &&
      labs(SD.XYs[i][1]-SD.XYs[j][1])<=10) ||
      (labs(SD.XYq[i][0]-SD.XYq[j][0])<=10 &&     //allow 10aa or 10 na diff
     labs(SD.XYq[i][1]-SD.XYq[j][0])<=10)) {
      Findel=0; break;
     }
     else { Findel=1; }
    }
    if(Findel==0) break;
   }                                              //determine whether there is repeat structure

   if(Findel==1) {
    for (i = 0; i < HSP - 1; i++) {
     for (j = i + 1; j < HSP; j++) {
      if (((SD.XYs[i][1] > SD.XYs[i][0] &&
       labs(SD.XYs[i][1] - SD.XYs[j][0]) <= AOLSize) ||
       (SD.XYs[i][1] < SD.XYs[i][0] &&
       labs(SD.XYs[i][0] - SD.XYs[j][1]) <= AOLSize)) &&

       ((SD.XYq[i][1] > SD.XYq[i][0] &&
       SD.XYq[i][0] < SD.XYq[j][0] &&
       SD.XYq[i][1] <= SD.XYq[j][0] - MinGaps) ||

       (SD.XYq[i][1] > SD.XYq[i][0] &&
       SD.XYq[i][0] > SD.XYq[j][0] &&
       SD.XYq[i][0] >= SD.XYq[j][1] + MinGaps) ||

       (SD.XYq[i][1] < SD.XYq[i][0] &&
       SD.XYq[i][0] < SD.XYq[j][0] &&
       SD.XYq[i][0] <= SD.XYq[j][1] - MinGaps) ||

       (SD.XYq[i][1] < SD.XYq[i][0] &&
       SD.XYq[i][0] > SD.XYq[j][0] &&
      SD.XYq[i][1] >= SD.XYq[j][0] + MinGaps))) {

       SDS.XYq[HSP2][0] = SD.XYq[i][0];
       SDS.XYq[HSP2][1] = SD.XYq[i][1];
       SDS.XYs[HSP2][0] = SD.XYs[i][0];
       SDS.XYs[HSP2][1] = SD.XYs[i][1];
       strcpy(SDS.E[HSP2], SD.E[i]);
       SDS.Score[HSP2] = SD.Score[i];
       SDS.SCov[HSP2] = SD.SCov[i];
       SDS.QCov[HSP2] = SD.QCov[i];
       SDS.Iden[HSP2] = SD.Iden[i];
       SDS.Simi[HSP2] = SD.Simi[i];
       SDS.Gaps[HSP2] = SD.Gaps[i];
       strcpy(SDS.Frame[HSP2], SD.Frame[i]);

       Ic++;
       Inx = j;
       i = j - 1;
       HSP2++;
       break;
      }                                           //end of if()
     }
    }                                             //for(i=o; ...) {}
   }                                              //if(Findel==1) {}
   break;
  case 2:
   for(i=0; i<HSP-1; i++) {
    for(j=i+1; j<HSP; j++) {
     if(labs(SD.XYq[i][0]-SD.XYq[j][0])<=10 &&
     labs(SD.XYq[i][1]-SD.XYq[j][1])<=10) {
      Findel=0; break;
     }
     else { Findel=1; }
    }
    if(Findel==0) break;
   }                                              //determine whether there is repeat structure

   if(Findel==1) {
    switch(BST) {
     case blastx:  SIZE = MinGaps/3; break;
     case tblastn: case rpstblastn: SIZE = 3 * MinGaps; break;
     case blastp: case rpsblast: case blastn:
     case tblastx: SIZE = MinGaps; break;
    }
    for (i = 0; i < HSP - 1; i++) {
     for (j = i + 1; j < HSP; j++) {
      if (((SD.XYs[i][1] > SD.XYs[i][0] &&
       SD.XYs[i][1] <= SD.XYs[j][0] - SIZE) ||
       (SD.XYs[i][1] < SD.XYs[i][0] &&
       SD.XYs[i][0] <= SD.XYs[j][1] - SIZE)) &&

       ((SD.XYq[i][1] > SD.XYq[i][0] &&
       SD.XYq[i][0] < SD.XYq[j][0] &&
       labs(SD.XYq[i][1] - SD.XYq[j][0]) <= AOLSize) ||

       (SD.XYq[i][1] > SD.XYq[i][0] &&
       SD.XYq[i][0] > SD.XYq[j][0] &&
       labs(SD.XYq[i][0] - SD.XYq[j][1]) <= AOLSize) ||

       (SD.XYq[i][1] < SD.XYq[i][0] &&
       SD.XYq[i][0] < SD.XYq[j][0] &&
       abs(SD.XYq[i][0] - SD.XYq[j][1]) <= AOLSize) ||

       (SD.XYq[i][1] < SD.XYq[i][0] &&
       SD.XYq[i][0] > SD.XYq[j][0] &&
      labs(SD.XYq[i][1] - SD.XYq[j][0]) <= AOLSize))) {

       SDS.XYq[HSP2][0] = SD.XYq[i][0];
       SDS.XYq[HSP2][1] = SD.XYq[i][1];
       SDS.XYs[HSP2][0] = SD.XYs[i][0];
       SDS.XYs[HSP2][1] = SD.XYs[i][1];
       strcpy(SDS.E[HSP2], SD.E[i]);
       SDS.Score[HSP2] = SD.Score[i];
       SDS.SCov[HSP2] = SD.SCov[i];
       SDS.QCov[HSP2] = SD.QCov[i];
       SDS.Iden[HSP2] = SD.Iden[i];
       SDS.Simi[HSP2] = SD.Simi[i];
       SDS.Gaps[HSP2] = SD.Gaps[i];
       strcpy(SDS.Frame[HSP2], SD.Frame[i]);

       Ic++;
       Inx = j;
       i = j - 1;
       HSP2++;
       break;
      }                                           //end of if()
     }
    }                                             //for(i=o; ...) {}
   }                                              //if(Findel==1) {}
   break;
 }

 if (Inx != 0) {
  SDS.XYq[HSP2][0] = SD.XYq[Inx][0];
  SDS.XYq[HSP2][1] = SD.XYq[Inx][1];
  SDS.XYs[HSP2][0] = SD.XYs[Inx][0];
  SDS.XYs[HSP2][1] = SD.XYs[Inx][1];
  strcpy(SDS.E[HSP2], SD.E[Inx]);
  SDS.Score[HSP2] = SD.Score[Inx];
  SDS.SCov[HSP2] = SD.SCov[Inx];
  SDS.QCov[HSP2] = SD.QCov[Inx];
  SDS.Iden[HSP2] = SD.Iden[Inx];
  SDS.Simi[HSP2] = SD.Simi[Inx];
  SDS.Gaps[HSP2] = SD.Gaps[Inx];
  strcpy(SDS.Frame[HSP2], SD.Frame[Inx]);
  HSP2++;
 }
 if (HSP2 > 1) {
  if(Fmt==html) {
   if(bgci==0) {
    bgci=2;
   }
   else {
    bgci=0;
   }
  }
  print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP2, MaxHSPs, SDS, Fmt, BST, Pstyle, bgci);
 }
 (*F).flush();
}                                                 // void AltSplicing() {}


void FullCDs(ostream *F, char *SQ, char *DB, char *ID, char *Annotation, char *SP,
int Nbp, int SLen, int HSP, DTtype SD, OutFmt Fmt, BLAST BST,
int Pstyle, int &Gc, int Startq, int Endq)
{
 int   i, j;
 float SMax, QMax;

 if (HSP == 1) {
                                                  //Qx<Qy and Sx<Sy
  if(SD.XYq[0][0]<SD.XYq[0][1] && SD.XYs[0][0]<SD.XYs[0][1]) {

   if((SD.XYs[0][0] <= StartPosi+1  ||  SD.XYq[0][0] <= Startq+1)  &&
    (SLen - SD.XYs[0][1] <= EndPosi  ||  Nbp - SD.XYq[0][1] <= Endq)  &&
   SD.SCov[0] >= SCpct && SD.QCov[0] >= QCpct) {

    Gc++;

    if(Fmt==html) {
     if(bgcg==0) {
      bgcg=2;
     }
     else {
      bgcg=0;
     }
    }

    print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP, MaxHSPs, SD, Fmt, BST, Pstyle, bgcg);
   }                                              //   end if (SD.XYs[0][0] <=....
  }                                               // end if (SD.XYq[0][0]< ....

                                                  //Qx>Qy and Sx<Sy
  if(SD.XYq[0][0]>SD.XYq[0][1] && SD.XYs[0][0]<SD.XYs[0][1]) {

   if((SD.XYs[0][0] <= StartPosi+1  ||  Nbp - SD.XYq[0][0] <= Startq)  &&
    (SLen - SD.XYs[0][1] <= EndPosi  ||  SD.XYq[0][1] <= Endq+1)  &&
   SD.SCov[0] >= SCpct && SD.QCov[0] >= QCpct) {

    Gc++;

    if(Fmt==html) {
     if(bgcg==0) {
      bgcg=2;
     }
     else {
      bgcg=0;
     }
    }

    print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP, MaxHSPs, SD, Fmt, BST, Pstyle, bgcg);
   }                                              //end if ((SD.XYs...
  }                                               //end else (SD.XYs[0][0]<....

                                                  //Qx<Qy and Sx>Sy
  if(SD.XYq[0][0]<SD.XYq[0][1] && SD.XYs[0][0]>SD.XYs[0][1]) {

   if((SLen - SD.XYs[0][0] <= StartPosi  ||  SD.XYq[0][0] <= Startq+1)  &&
    (SD.XYs[0][1] <= EndPosi+1  ||  Nbp - SD.XYq[0][1] <= Endq)  &&
   SD.SCov[0] >= SCpct && SD.QCov[0] >= QCpct) {

    Gc++;

    if(Fmt==html) {
     if(bgcg==0) {
      bgcg=2;
     }
     else {
      bgcg=0;
     }
    }

    print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP, MaxHSPs, SD, Fmt, BST, Pstyle, bgcg);
   }                                              //end if ((SD.XYs...
  }                                               //end else (SD.XYs[0][0]<....

                                                  //Qx>Qy and Sx>Sy
  if(SD.XYq[0][0]>SD.XYq[0][1] && SD.XYs[0][0]>SD.XYs[0][1]) {

   if((SLen - SD.XYs[0][0] <= StartPosi  ||  Nbp - SD.XYq[0][0] <= Startq)  &&
    (SD.XYs[0][1] <= EndPosi+1  ||  SD.XYq[0][1] <= Endq+1)  &&
   SD.SCov[0] >= SCpct && SD.QCov[0] >= QCpct) {

    Gc++;

    if(Fmt==html) {
     if(bgcg==0) {
      bgcg=2;
     }
     else {
      bgcg=0;
     }
    }

    print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP, MaxHSPs, SD, Fmt, BST, Pstyle, bgcg);
   }                                              //end if ((SD.XYs...
  }                                               //end else (SD.XYs[0][0]<....
 }                                                //end if HSP==1

 else {
  SortDT(SD, HSP, 1);                             //sort the data based on the subject coordinates
  SMax = SD.SCov[0];
  QMax = SD.QCov[0];
  for (i = 0; i < HSP - 1; i++) {
   for (j = i + 1; j < HSP; j++) {
    if (((SD.XYs[i][1] > SD.XYs[i][0] &&
     SD.XYs[i][1] <= SD.XYs[j][0]) ||

     (SD.XYs[i][1] < SD.XYs[i][0] &&
     SD.XYs[i][0] <= SD.XYs[j][1])) &&

     ((SD.XYq[i][1] > SD.XYq[i][0] &&
     SD.XYq[i][0] < SD.XYq[j][0] &&
     SD.XYq[i][1] <= SD.XYq[j][0]) ||

     (SD.XYq[i][1] > SD.XYq[i][0] &&
     SD.XYq[i][0] > SD.XYq[j][0] &&
     SD.XYq[i][0] >= SD.XYq[j][1]) ||

     (SD.XYq[i][1] < SD.XYq[i][0] &&
     SD.XYq[i][0] < SD.XYq[j][0] &&
     SD.XYq[i][0] <= SD.XYq[j][1]) ||

     (SD.XYq[i][1] < SD.XYq[i][0] &&
     SD.XYq[i][0] > SD.XYq[j][0] &&
    SD.XYq[i][1] >= SD.XYq[j][0]))) {
     SMax = SMax + SD.SCov[j];
     QMax = QMax + SD.QCov[j];
     i = j - 1;
     break;
    }
   }
  }
  //SD.XYs[HSP][1] changed to SD.XYs[HSP-1][1]

                                                  //Qx<Qy and Sx<Sy
  if(SD.XYq[0][0]<SD.XYq[0][1] && SD.XYs[0][0]<SD.XYs[0][1]) {

   if((SD.XYs[0][0] <= StartPosi+1  ||  SD.XYq[0][0] <= Startq+1)  &&
    (SLen - SD.XYs[HSP-1][1] <= EndPosi  ||  Nbp - SD.XYq[HSP-1][1] <= Endq)  &&
   SMax >= SCpct && QMax >= QCpct) {

    Gc++;

    if(Fmt==html) {
     if(bgcg==0) {
      bgcg=2;
     }
     else {
      bgcg=0;
     }
    }

    print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP, MaxHSPs, SD, Fmt, BST, Pstyle, bgcg);
   }                                              //end if (SMax >=...
  }                                               //end if (SD.XYq[0][0]<....

                                                  //Qx>Qy and Sx<Sy
  if(SD.XYq[0][0]>SD.XYq[0][1] && SD.XYs[0][0]<SD.XYs[0][1]) {
   if((SD.XYs[0][0] <= StartPosi+1  ||  Nbp - SD.XYq[0][0] <= Startq)  &&
    (SLen - SD.XYs[HSP-1][1] <= EndPosi  ||  SD.XYq[HSP-1][1] <= Endq+1)  &&
   SMax >= SCpct && QMax >= QCpct) {

    Gc++;

    if(Fmt==html) {
     if(bgcg==0) {
      bgcg=2;
     }
     else {
      bgcg=0;
     }
    }

    print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP, MaxHSPs, SD, Fmt, BST, Pstyle, bgcg);
   }                                              //end if (SMax >=...
  }                                               //end if (SD.XYq[0][0]<....

                                                  //Qx<Qy and Sx>Sy
  if(SD.XYq[0][0]<SD.XYq[0][1] && SD.XYs[0][0]>SD.XYs[0][1]) {
   if((SLen - SD.XYs[HSP-1][0] <= StartPosi  ||  SD.XYq[HSP-1][0] <= Startq+1)  &&
    (SD.XYs[0][1] <= EndPosi+1  ||  Nbp - SD.XYq[0][1] <= Endq)  &&
   SMax >= SCpct && QMax >= QCpct) {

    Gc++;

    if(Fmt==html) {
     if(bgcg==0) {
      bgcg=2;
     }
     else {
      bgcg=0;
     }
    }

    print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP, MaxHSPs, SD, Fmt, BST, Pstyle, bgcg);
   }                                              //end if (SMax >=...
  }                                               //end if (SD.XYq[0][0]<....

                                                  //Qx>Qy and Sx>Sy
  if(SD.XYq[0][0]<SD.XYq[0][1] && SD.XYs[0][0]>SD.XYs[0][1]) {
   if((SLen - SD.XYs[HSP-1][0] <= StartPosi  ||  Nbp - SD.XYq[HSP-1][0] <= Startq)  &&
    (SD.XYs[HSP-1][1] <= EndPosi+1  ||  SD.XYq[HSP-1][1] <= Endq+1)  &&
   SMax >= SCpct && QMax >= QCpct) {

    Gc++;

    if(Fmt==html) {
     if(bgcg==0) {
      bgcg=2;
     }
     else {
      bgcg=0;
     }
    }

    print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP, MaxHSPs, SD, Fmt, BST, Pstyle, bgcg);
   }                                              //end if (SMax >=...
  }                                               //end if (SD.XYq[0][0]<....

 }                                                //end else HSP==1
 (*F).flush();
}                                                 //FullCDs() {}


void Homolog(ostream *F, char *SQ, char *DB, char *ID, char *Annotation, char *SP,
int Nbp, int SLen, int HSP, DTtype SD, OutFmt Fmt, BLAST BST,
int Pstyle, int &Hc)
{
 int    i, j;
 int    TC=0, HSP2=0;
 DTtype SDS;
 int    Inx[MaxHSPs];
 float  SMax;

 if (HSP == 1) {
  if (SD.Iden[0] >= Hpct && SD.SCov[0] >= HCpct) {

   if(Fmt==html) {
    if(bgch==0) {
     bgch=2;
    }
    else {
     bgch=0;
    }
   }

   print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP, MaxHSPs, SD, Fmt, BST, Pstyle, bgch);
   Hc++;
  }
 }
 else {
  for (i = 0; i < HSP; i++) {
   if (SD.Iden[i] >= Hpct) {
    SDS.XYq[TC][0] = SD.XYq[i][0];
    SDS.XYq[TC][1] = SD.XYq[i][1];
    SDS.XYs[TC][0] = SD.XYs[i][0];
    SDS.XYs[TC][1] = SD.XYs[i][1];
    strcpy(SDS.E[TC], SD.E[i]);
    SDS.Score[TC] = SD.Score[i];
    SDS.SCov[TC] = SD.SCov[i];
    SDS.QCov[TC] = SD.QCov[i];
    SDS.Iden[TC] = SD.Iden[i];
    SDS.Simi[TC] = SD.Simi[i];
    SDS.Gaps[TC] = SD.Gaps[i];
    strcpy(SDS.Frame[TC], SD.Frame[i]);
    TC++;
   }
  }

  SortDT(SDS, TC, 2);                             //sort the data based on e-values
  SMax = SDS.SCov[0];
  Inx[HSP2] = 0;

  for (i = 0; i < TC - 1; i++) {
   for (j = i + 1; j < TC; j++) {
    if (((SDS.XYs[i][1] > SDS.XYs[i][0] &&
     SDS.XYs[j][0] > SDS.XYs[i][0] &&
     SDS.XYs[i][1] <= SDS.XYs[j][0]) ||

     (SDS.XYs[i][1] > SDS.XYs[i][0] &&
     SDS.XYs[j][0] < SDS.XYs[i][0] &&
     SDS.XYs[i][0] >= SDS.XYs[j][1]) ||

     (SDS.XYs[i][1] < SDS.XYs[i][0] &&
     SDS.XYs[j][0] > SDS.XYs[i][0] &&
     SDS.XYs[i][0] <= SDS.XYs[j][1]) ||

     (SDS.XYs[i][1] < SDS.XYs[i][0] &&
     SDS.XYs[j][0] < SDS.XYs[i][0] &&
     SDS.XYs[i][1] >= SDS.XYs[j][0])) &&

     ((SDS.XYq[i][1] > SDS.XYq[i][0] &&
     SDS.XYq[i][0] < SDS.XYq[j][0] &&
     (SDS.XYq[i][1] - MAO) <= SDS.XYq[j][0]) ||

     (SDS.XYq[i][1] > SDS.XYq[i][0] &&
     SDS.XYq[i][0] > SDS.XYq[j][0] &&
     (SDS.XYq[i][0] + MAO) >= SDS.XYq[j][1]) ||

     (SDS.XYq[i][1] < SDS.XYq[i][0] &&
     SDS.XYq[i][0] < SDS.XYq[j][0] &&
     (SDS.XYq[i][0] - MAO) <= SDS.XYq[j][1]) ||

     (SDS.XYq[i][1] < SDS.XYq[i][0] &&
     SDS.XYq[i][0] > SDS.XYq[j][0] &&
    (SDS.XYq[i][1] + MAO) >= SDS.XYq[j][0]))) {
     SMax = SMax + SDS.SCov[j];
     HSP2++;
     Inx[HSP2] = j;
     i = j - 1;
     break;
    }
   }
  }
  if (SMax >= HCpct) {
   for (i = 0; i < HSP2; i++) {
    SD.XYq[i][0] = SDS.XYq[Inx[i]][0];
    SD.XYq[i][1] = SDS.XYq[Inx[i]][1];
    SD.XYs[i][0] = SDS.XYs[Inx[i]][0];
    SD.XYs[i][1] = SDS.XYs[Inx[i]][1];
    strcpy(SD.E[i], SDS.E[Inx[i]]);
    SD.Score[i] = SDS.Score[Inx[i]];
    SD.SCov[i] = SDS.SCov[Inx[i]];
    SD.QCov[i] = SDS.QCov[Inx[i]];
    SD.Iden[i] = SDS.Iden[Inx[i]];
    SD.Simi[i] = SDS.Simi[Inx[i]];
    SD.Gaps[i] = SDS.Gaps[Inx[i]];
    strcpy(SD.Frame[i], SDS.Frame[Inx[i]]);
   }

   if(Fmt==html) {
    if(bgch==0) {
     bgch=2;
    }
    else {
     bgch=0;
    }
   }

   print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP2, MaxHSPs, SD, Fmt, BST, Pstyle,bgch);
  }
 }
 (*F).flush();
}                                                 //Annotate() {}


void Repeats(ostream *F, char *SQ, char *DB, char *ID, char *Annotation, char *SP,
int Nbp, int SLen, int HSP, DTtype SD, OutFmt Fmt, BLAST BST,
int Pstyle, int &Rc)
{

 int     i, j;
 int     Inx = 0, SIZE, HSP2 = 0;
 DTtype  SDS;
 switch(BST) {
  case blastx:  SIZE = MinReps/3; break;          //query nucleotide, subject amino acid
                                                  //query amino acid, subject nucleotide
  case tblastn: case rpstblastn: SIZE = MinReps*3; break;
  case blastp: case rpsblast: case tblastx:
  case blastn:  SIZE = MinReps; break;
 }
 SortDT(SD, HSP, 1);                              //sort the data based on the subject coordinates

 switch (RepsSrc) {
  case 2:
   for (i = 0; i < HSP - 1; i++) {
    for (j = i + 1; j < HSP; j++) {
     if ((((SD.XYq[i][1] > SD.XYq[i][0] &&
      SD.XYq[i][0] < SD.XYq[j][0] &&
      SD.XYq[i][1] >= SD.XYq[j][0] + MinReps) ||

      (SD.XYq[i][1] > SD.XYq[i][0] &&
      SD.XYq[i][0] > SD.XYq[j][0] &&
      SD.XYq[i][0] <= SD.XYq[j][1] - MinReps) ||

      (SD.XYq[i][1] < SD.XYq[i][0] &&
      SD.XYq[i][0] < SD.XYq[j][0] &&
      SD.XYq[i][0] >= SD.XYq[j][1] + MinReps) ||

      (SD.XYq[i][1] < SD.XYq[i][0] &&
      SD.XYq[i][0] > SD.XYq[j][0] &&
      SD.XYq[i][1] <= SD.XYq[j][0] - MinReps) ||

      (SD.XYq[i][0] == SD.XYq[j][0] &&
      SD.XYq[i][1] == SD.XYq[j][1] &&
      (abs(SD.XYq[i][1]-SD.XYq[i][0])-MinReps)>=0))) &&

      ((SD.XYs[i][1] > SD.XYs[i][0] &&
      SD.XYs[i][1] <= SD.XYs[j][0]) ||

      (SD.XYs[i][1] < SD.XYs[i][0] &&
     SD.XYs[i][0] <= SD.XYs[j][1]))) {

      SDS.XYq[HSP2][0] = SD.XYq[i][0];
      SDS.XYq[HSP2][1] = SD.XYq[i][1];
      SDS.XYs[HSP2][0] = SD.XYs[i][0];
      SDS.XYs[HSP2][1] = SD.XYs[i][1];
      strcpy(SDS.E[HSP2], SD.E[i]);
      SDS.Score[HSP2] = SD.Score[i];
      SDS.SCov[HSP2] = SD.SCov[i];
      SDS.QCov[HSP2] = SD.QCov[i];
      SDS.Iden[HSP2] = SD.Iden[i];
      SDS.Simi[HSP2] = SD.Simi[i];
      SDS.Gaps[HSP2] = SD.Gaps[i];
      strcpy(SDS.Frame[HSP2], SD.Frame[i]);
      Inx = j;
      Rc++;
      i = j - 1;
      HSP2++;
      break;
     }
    }
   }
   break;
  case 1:
   for (i = 0; i < HSP - 1; i++) {
    for (j = i + 1; j < HSP; j++) {
     if ((
      ((SD.XYs[i][1] > SD.XYs[i][0] &&
      SD.XYs[i][1] >= SD.XYs[j][0] + SIZE) ||

      (SD.XYs[i][1] < SD.XYs[i][0] &&
      SD.XYs[i][0] >= SD.XYs[j][1] + SIZE) ||

      (SD.XYs[i][0] == SD.XYs[j][0] &&
      SD.XYs[i][1] == SD.XYs[j][1])) &&

      ((SD.XYq[i][1] > SD.XYq[i][0] &&
      SD.XYq[i][0] < SD.XYq[j][0] &&
      SD.XYq[i][1] <= SD.XYq[j][0]) ||

      (SD.XYq[i][1] > SD.XYq[i][0] &&
      SD.XYq[i][0] > SD.XYq[j][0] &&
      SD.XYq[i][0] >= SD.XYq[j][1]) ||

      (SD.XYq[i][1] < SD.XYq[i][0] &&
      SD.XYq[i][0] < SD.XYq[j][0] &&
      SD.XYq[i][0] <= SD.XYq[j][1]) ||

      (SD.XYq[i][1] < SD.XYq[i][0] &&
      SD.XYq[i][0] > SD.XYq[j][0] &&
     SD.XYq[i][1] >= SD.XYq[j][0])))) {

      SDS.XYq[HSP2][0] = SD.XYq[i][0];
      SDS.XYq[HSP2][1] = SD.XYq[i][1];
      SDS.XYs[HSP2][0] = SD.XYs[i][0];
      SDS.XYs[HSP2][1] = SD.XYs[i][1];
      strcpy(SDS.E[HSP2], SD.E[i]);
      SDS.Score[HSP2] = SD.Score[i];
      SDS.SCov[HSP2] = SD.SCov[i];
      SDS.QCov[HSP2] = SD.QCov[i];
      SDS.Iden[HSP2] = SD.Iden[i];
      SDS.Simi[HSP2] = SD.Simi[i];
      SDS.Gaps[HSP2] = SD.Gaps[i];
      strcpy(SDS.Frame[HSP2], SD.Frame[i]);
      Inx = j;
      Rc++;
      i = j - 1;
      HSP2++;
      break;
     }
    }
   }
   break;
 }
 if (Inx != 0) {
  SDS.XYq[HSP2][0] = SD.XYq[Inx][0];
  SDS.XYq[HSP2][1] = SD.XYq[Inx][1];
  SDS.XYs[HSP2][0] = SD.XYs[Inx][0];
  SDS.XYs[HSP2][1] = SD.XYs[Inx][1];
  strcpy(SDS.E[HSP2], SD.E[Inx]);
  SDS.Score[HSP2] = SD.Score[Inx];
  SDS.SCov[HSP2] = SD.SCov[Inx];
  SDS.QCov[HSP2] = SD.QCov[Inx];
  SDS.Iden[HSP2] = SD.Iden[Inx];
  SDS.Simi[HSP2] = SD.Simi[Inx];
  SDS.Gaps[HSP2] = SD.Gaps[Inx];
  strcpy(SDS.Frame[HSP2], SD.Frame[Inx]);
  HSP2++;
 }
 if (HSP2 > 1) {
  if(Fmt==html) {
   if(bgch==0) {
    bgch=2;
   }
   else {
    bgch=0;
   }
  }

  print(F, SQ, DB, ID, Annotation, SP, Nbp, SLen, HSP2, MaxHSPs, SDS, Fmt, BST, Pstyle, bgch);
 }
 (*F).flush();
}                                                 //Repeats() {}
#endif
